#This code was written by Tobyn Branck and provides the AMR analysis and Figure 6 visualization

library("RNOmni")
library("ggplot2")
library("grid")
library("vegan")
library(tidyverse)
library(lme4)
library(factoextra)
library(ade4)
library(FactoMineR)
library("plyr")
library("dbplyr")
library(scales)
library(ggbreak)
library(grid)
library(gtable)
library(gridExtra)
library(scatterplot3d)
library(reshape2)
library(gtools)

### import metadata
metadata = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/all_metadata_preformatted.csv", header=T, check.names = F))
rownames(metadata) = metadata$sample_id_metaphlan

#metadata = ddply(metadata, .(study_readable), mutate, id = seq_along(study_readable))

### import AMR genes families (uniref90s that mapped to CARD database) ###
AMR_genes = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/ALL_SAMPS_joined_genefams_relab_unstratified_CARD_AMR_RENAMED.tsv", header=T, check.names = F))
rownames(AMR_genes) = AMR_genes$'# Gene Family'
AMR_genes$'# Gene Family' = NULL
colnames(AMR_genes) = gsub("_Abundance-RPKs","",colnames(AMR_genes))

dog_samps = rownames(metadata)[metadata$species=="dog"]
cat_samps = rownames(metadata)[metadata$species=="cat"]
human_samps = rownames(metadata)[metadata$species=="human"]
hmp1_II_samps = rownames(metadata)[metadata$study_readable=="HMP1-II"]
madagascar_samps = rownames(metadata)[metadata$study_readable=="Madagascar"]

# remove madagascar samples
metadata = metadata[!metadata$study_readable=="Madagascar",]
AMR_genes = AMR_genes[,colnames(AMR_genes) %in% rownames(metadata)]

dog_AMR = AMR_genes[,colnames(AMR_genes) %in% dog_samps]
cat_AMR = AMR_genes[,colnames(AMR_genes) %in% cat_samps]
hmp_AMR = AMR_genes[,colnames(AMR_genes) %in% hmp1_II_samps]

#sort genes by highest prevalence
dog_AMR$prev = rowSums(dog_AMR > 0)/dim(dog_AMR)[2]
dog_AMR = dog_AMR[order(dog_AMR$prev,decreasing=TRUE),]
dog_AMR = dog_AMR[dog_AMR$prev>0.001459854,]

cat_AMR$prev = rowSums(cat_AMR > 0)/dim(cat_AMR)[2]
cat_AMR = cat_AMR[order(cat_AMR$prev,decreasing=TRUE),]
cat_AMR = cat_AMR[cat_AMR$prev>0.008174387,]

hmp_AMR$prev = rowSums(hmp_AMR > 0)/dim(hmp_AMR)[2]
hmp_AMR = hmp_AMR[order(hmp_AMR$prev,decreasing=TRUE),]
hmp_AMR = hmp_AMR[hmp_AMR$prev>0.01260504,]

amr_genes_keep = union(rownames(cat_AMR),rownames(dog_AMR))
amr_genes_keep = union(amr_genes_keep,rownames(hmp_AMR))

AMR_genes_filtered = AMR_genes[rownames(AMR_genes) %in% amr_genes_keep,]

AMR_genes_filtered = as.data.frame(t(AMR_genes_filtered))
AMR_genes_filtered = AMR_genes_filtered[rowSums(AMR_genes_filtered) != 0, ]
metadata = metadata[rownames(metadata) %in% rownames(AMR_genes_filtered),]
metadata = metadata[mixedorder(rownames(metadata)),]
AMR_genes_filtered = AMR_genes_filtered[mixedorder(rownames(AMR_genes_filtered)),]

metadata_for_amr_adonis = metadata[rownames(metadata) %in% rownames(AMR_genes_filtered),]
AMR_genes_filtered = AMR_genes_filtered[gtools::mixedorder(rownames(AMR_genes_filtered)),]
amr_adonis = adonis(AMR_genes_filtered ~ metadata_for_amr_adonis$species, data = metadata_for_amr_adonis, method = "bray",na.rm=TRUE)

AMR_genes_filtered_maas = as.data.frame(t(AMR_genes_filtered))

library(Maaslin2)
Maaslin2(AMR_genes_filtered_maas,metadata_for_amr_adonis,output = "/Users/tobynbranck/Documents/pets_meta/maaslin_pets_HostsStrat_hmpRef_CARD_AMR_Noprevfilter",fixed_effects = c("species"),reference=c("species,human"), random_effects = c("study_readable"),min_prevalence = 0)
Maaslin2(AMR_genes_filtered_maas,metadata_for_amr_adonis,output = "/Users/tobynbranck/Documents/pets_meta/maaslin_pets_HostsStrat_dogRef_CARD_AMR_Noprevfilter",fixed_effects = c("species"),reference=c("species,dog"), random_effects = c("study_readable"),min_prevalence = 0)
Maaslin2(AMR_genes_filtered_maas,metadata_for_amr_adonis,output = "/Users/tobynbranck/Documents/pets_meta/maaslin_pets_HostsStrat_catRef_CARD_AMR_Noprevfilter",fixed_effects = c("species"),reference=c("species,cat"), random_effects = c("study_readable"),min_prevalence = 0)

## PcoA
# bray-curtis dissimilarity
all = data.frame(AMR_genes_filtered, metadata)
amr_dist = vegdist(AMR_genes_filtered, method = "bray")

weights = c(case_when(metadata$species == "human" ~ 1/238,
                      metadata$species == "cat" ~ 1/367,
                      metadata$species == "dog" ~ 1/2055)) # weighted by sample size

pcoa = wcmdscale(amr_dist, k = 2, eig = TRUE, w = weights)

positions = pcoa$points
colnames(positions) = c("pcoa1","pcoa2")

100*pcoa$eig / sum(pcoa$eig)
percent_var_explained = metagMisc::eig_perc(pcoa$eig, positive = T, plot = F)
percent_var_explained = format(round(percent_var_explained[1:2],digits = 2),nsmall=1,trim=TRUE)
labs = c(glue::glue("PCoA1 [{percent_var_explained[1]}%]"),
         glue::glue("PCoA2 [{percent_var_explained[2]}%]"))
positions = as.data.frame(positions)

metadata_ord = metadata[rownames(metadata) %in% rownames(positions),]
metadata_ord$host_stratified = NA
metadata_ord$host_stratified[metadata_ord$study_id == 'HMP1-II'] = 'HMP1-II'
metadata_ord$host_stratified[metadata_ord$species == 'dog'] = 'dog'
metadata_ord$host_stratified[metadata_ord$species == 'cat'] = 'cat'

positions$host = metadata_ord$species[rownames(positions) %in% rownames(metadata_ord)]
positions$host2 = metadata_ord$host_stratified[rownames(positions) %in% rownames(metadata_ord)]

# calculate weighted average scores of genes driving the cluster of PCoA
wascores = data.frame(wascores(positions[1:2], AMR_genes_filtered))

# maaslin results
unifrec_catRef = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/maaslin_pets_HostsStrat_catRef_CARD_AMR_Noprevfilter/significant_results.tsv", header=T, check.names = F)) %>% mutate(reference = "cat")
unifrec_dogRef = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/maaslin_pets_HostsStrat_dogRef_CARD_AMR_Noprevfilter/significant_results.tsv", header=T, check.names = F)) %>% mutate(reference = "dog")
unifrec_hmpRef = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/maaslin_pets_HostsStrat_hmpRef_CARD_AMR_Noprevfilter/significant_results.tsv", header=T, check.names = F)) %>% mutate(reference = "HMP1-II")

# top 4 coefficients genes among the significant results in each host species
unifrec_catRef_dog_vs_cat = unifrec_catRef[order(abs(unifrec_catRef$coef), decreasing = TRUE), ] %>% filter(value == "dog")
unifrec_hmpRef_dog_vs_human = unifrec_hmpRef[order(abs(unifrec_hmpRef$coef), decreasing = TRUE), ] %>% filter(value == "dog")
unifrec_hmpRef_cat_vs_human = unifrec_hmpRef[order(abs(unifrec_hmpRef$coef), decreasing = TRUE), ] %>% filter(value == "cat")

maaslin_sig_list = union(unifrec_catRef_dog_vs_cat[1:4, 1], unifrec_hmpRef_dog_vs_human[1:4, 1]) %>% 
  union(unifrec_hmpRef_cat_vs_human[1:4, 1])

# reformat the maaslin genes annotation
maaslin_sig_list = sub("\\.\\.", ": ", maaslin_sig_list)
maaslin_sig_list = gsub("\\.", " ", maaslin_sig_list)
maaslin_sig_list = gsub("\\:.*", "", maaslin_sig_list)

# grep lines containing masslin_sig_list
matching_rows = sapply(rownames(wascores), function(row_name) { 
  any(sapply(maaslin_sig_list, function(pattern) {
    grepl(pattern, row_name)
  }))
})

# subset the dataframe based on the rows that matched
data_wa_sub = wascores[matching_rows, ]
data_wa_sub2 = wascores[c('UniRef90_A0A2R4H2Z9: rRNA methylase',
                          'UniRef90_D6PYN7: DfrA14 (Fragment)',
                          'UniRef90_A0A127SV09: Chloramphenicol acetyltransferase',
                          'UniRef90_A0A1Y1CU85: Aminoglycoside N(6&apos )-acetyltransferase',
                          'UniRef90_A0A174XA02: Beta-lactamase',
                          'UniRef90_P0A0C2: Bifunctional AAC/APH'), ] # selected by visualization


data_wa_sub3 = rbind(data_wa_sub, data_wa_sub2) # combined 
rownames(data_wa_sub3) = gsub("UniRef90_", "", rownames(data_wa_sub3))

cairo_pdf("CARDAMR_ord_Allhosts.pdf", width = 8, height = 6)

ggplot() + 
  geom_point(data = positions %>% as_tibble(rownames = "samples",eig=TRUE), 
             aes(x = pcoa1, y = pcoa2, color = host), size = 4, alpha = 0.5, show.legend = F) + 
  geom_text(data = data_wa_sub3, aes(x = pcoa1, y = pcoa2, label = rownames(data_wa_sub3)), 
            check_overlap = F, vjust = 0, hjust = 0.5, size = 3, color = "black") +
  theme_classic() + 
  theme(legend.text = element_text(size = 12), 
        legend.title = element_text(size = 12, face = "bold"), 
        legend.position = "right",
        axis.text = element_text(size = 12), 
        axis.title = element_text(size = 12, face = "bold")) +
  scale_color_manual(values=c("indianred","#E69F00","#56B4E9")) + 
  labs(x = labs[1],y = labs[2], title = NULL)

dev.off()

## heatmap
# top 20 most prevalent per host
top_cat = rownames(cat_AMR)[1:15]
top_dog = rownames(dog_AMR)[1:15]
top_hmp = rownames(hmp_AMR)[1:15]

top_union = union(top_cat,top_dog)
top_union = union(top_union,top_hmp)

# top 15 coefficients genes among significant maaslin results
maaslin_sig8_list = union(unique(unifrec_catRef_dog_vs_cat$feature)[1:15], 
                          unique(unifrec_hmpRef_dog_vs_human$feature)[1:15]) %>% 
  union(unique(unifrec_hmpRef_dog_vs_human$feature)[1:15])

# reformat the maaslin genes annotation
maaslin_sig8_list = sub("\\.\\.", ": ", maaslin_sig8_list)
maaslin_sig8_list = gsub("\\.", " ", maaslin_sig8_list)
maaslin_sig8_list = gsub("\\:.*", "", maaslin_sig8_list)

# grep lines containing masslin_sig8_list
matching_rows = sapply(rownames(AMR_genes), function(row_name) {
  any(sapply(maaslin_sig8_list, function(pattern) {
    grepl(pattern, row_name)
  }))
})

most_prev = AMR_genes[matching_rows, ]

min = min(most_prev[most_prev>0])/10 # set 0 to be 1/10 of the minimum relative abundance = 1.79949e-09
most_prev[most_prev == 0] = min
most_prev = log10(most_prev)

most_prev = most_prev[,colnames(most_prev) %in% rownames(metadata)] # samples matched with metadata
rownames(most_prev) = gsub("UniRef90_", "", rownames(most_prev))
colnames(most_prev) = NULL # matrix

metadata_hm = metadata %>% select(c("Study ID" = study_readable, "Host Species" = species)) # metadata

# color setting
col = list(`Host Species`= c("cat" = "indianred","dog" = "#E69F00","human" = "#56B4E9"),
           `Study ID` = c('HMP1-II' = "#56B4E9", 'Cross-sectional Study2' = "#b7aaba", 'Cross-sectional Study3' = "#d44ab4", 
                          'Deusch et al. (2014)' = "#639CCF", 'Allaway et al.' = "#31378c", 'Deusch et al. (2015)' = "#6d81ae", 
                          'DietInt Study4' = "#798C7E", 'DietInt Study5' = "#b05c63", 'Cross-sectional Study1' = "#FFFFB3", 
                          'DietInt Study1' = "#d69d68", 'DietInt Study3' = "#7eda86", 'DietInt Study2' = "#fbc086",
                          'Young et al.' = "#74d0d1", 'Ateba et al.' = "#e0a8f5", 'Liu et al.' = "#d2bed7", 'Tanprasertsuk et al.' = "#c7a679",
                          'Ma et al.' = "#612141", 'Xu et al.' = "#ae4109", 'Alessandri et al.' = "#b435ee", 'Wang et al.' = "#e9fdc3",
                          'Maldonado-Contreras et al.' = "#c7f4fc",'Xu et al.' ="#ae4109"))


# plot
cairo_pdf("CARDAMR_heatmap_top30_maaslin_byhost.pdf",width = 16,height = 7)

pheatmap(mat = as.matrix(most_prev),
         name = "Log10 Relative Abundance",
         show_colnames = FALSE,
         color = colorRamp2(c(-8.744851,-1.890752), c("white","#333366")),
         border_color = NA, 
         annotation_col = metadata_hm,
         annotation_colors = col,
         cutree_cols = metadata_hm$`Host Species`,
         cluster_cols = T,
         legend = T,
         annotation_legend = FALSE)

dev.off()

###bring in CARD annotations
card_annotations = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/aro_index.tsv", header=T, check.names = F))

card_uniprot_align = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/output.tsv", header=F, check.names = F))
names(card_uniprot_align) = c("CARD_ID","uniref_ID","query_seq_length", "qstart","qend","slen","sstart","send","alignment_length","bscore",
                              "eval","percent_identity","qcovhsp","scovhsp")
card_uniprot_align$uniref_ID = gsub("\\|.*","",card_uniprot_align$uniref_ID)
card_uniprot_align$query_cov = ((card_uniprot_align$qend - card_uniprot_align$qstart + 1) / card_uniprot_align$query_seq_length)*100
card_uniprot_align$sub_cov = ((card_uniprot_align$send - card_uniprot_align$sstart + 1) / card_uniprot_align$slen)*100
card_uniprot_align = card_uniprot_align[card_uniprot_align$percent_identity>=90 & card_uniprot_align$query_cov>=80 & card_uniprot_align$sub_cov>=80,]
card_uniprot_align = card_uniprot_align %>% distinct %>% group_by(CARD_ID) %>% top_n(1, percent_identity)
card_uniprot_align = card_uniprot_align %>% distinct %>% group_by(CARD_ID) %>% top_n(1, query_cov)
card_uniprot_align = card_uniprot_align %>% distinct %>% group_by(CARD_ID) %>% top_n(1, sub_cov)
card_uniprot_align$CARD_ID = str_split_fixed(card_uniprot_align$CARD_ID, '\\|', 4)[,3]

AMR_genes_card_annotation = AMR_genes
rownames(AMR_genes_card_annotation) = gsub("\\:.*","",rownames(AMR_genes_card_annotation))

AMR_genes_card_annotation_CARD_ID = AMR_genes_card_annotation
AMR_genes_card_annotation_CARD_ID$CARD_ID = card_uniprot_align$CARD_ID[match(rownames(AMR_genes_card_annotation), card_uniprot_align$uniref_ID)]
AMR_genes_card_annotation_CARD_ID$drug_class = card_annotations$`Drug Class`[match(AMR_genes_card_annotation_CARD_ID$CARD_ID, card_annotations$`ARO Accession`)]
AMR_genes_card_annotation_CARD_ID$resistance_mech = card_annotations$`Resistance Mechanism`[match(AMR_genes_card_annotation_CARD_ID$CARD_ID, card_annotations$`ARO Accession`)]
AMR_genes_card_annotation_CARD_ID$uniref90 = rownames(AMR_genes_card_annotation_CARD_ID)

AMR_genes_card_annotation_CARD_ID_drugStrat = AMR_genes_card_annotation_CARD_ID %>% separate_rows(drug_class,sep = ";")

abx_df = melt(AMR_genes_card_annotation_CARD_ID_drugStrat, id='drug_class')
abx_df$species = metadata$species[match(abx_df$variable,rownames(metadata))]
abx_df$value = as.numeric(abx_df$value)
abx_df = aggregate(value ~ drug_class + variable + species, data=abx_df, sum)

abx_df_log = abx_df
abx_df_log[abx_df_log==0] = 0.0000000001
abx_df_log$value = log10(abx_df_log$value)
abx_df_log$value = as.numeric(abx_df_log$value)

#"un-melt" abx_df and run maaslin and then annotated figure
abx_df_pivot = dcast(data = abx_df,formula = drug_class~variable,fun.aggregate = sum,value.var = "value")
rownames(abx_df_pivot) = abx_df_pivot$drug_class
abx_df_pivot$drug_class = NULL

# abx --> drug classes
AMR_genes_card_annotation_CARD_ID_drugStrat$ABX_Class = AMR_genes_card_annotation_CARD_ID_drugStrat$drug_class
AMR_genes_card_annotation_CARD_ID_drugStrat_Action = AMR_genes_card_annotation_CARD_ID_drugStrat %>% 
  mutate(ABX_Class = case_when(drug_class == "tetracycline antibiotic" ~ "Tetracyclines",
                                 drug_class == "aminocoumarin antibiotic"  ~ "Aminocoumarins",
                                 drug_class == "aminoglycoside antibiotic" ~ "Aminoglycosides",
                                 drug_class == "carbapenem" ~ "B-lactams",
                                 drug_class == "cephalosporin" ~ "B-lactams",
                                 drug_class == "cephamycin" ~ "B-lactams",
                                 drug_class == "diaminopyrimidine antibiotic" ~ "Diaminopyrimidines",
                                 drug_class == "disinfecting agents and antiseptics" ~ "Disinfecting agents and antiseptics",
                                 drug_class == "fluoroquinolone antibiotic" ~ "Quinolones",
                                 drug_class == "fusidane antibiotic" ~ "Fusidanes",
                                 drug_class == "glycopeptide antibiotic" ~ "Glycopeptides",
                                 drug_class == "glycylcycline" ~ "Tetracyclines",
                                 drug_class == "lincosamide antibiotic" ~ "Lincosamides",
                                 drug_class == "macrolide antibiotic" ~ "Macrolides",
                                 drug_class == "monobactam" ~ "B-lactams",
                                 drug_class == "mupirocin-like antibiotic" ~ "Pleuromutilins",
                                 drug_class == "nitrofuran antibiotic" ~ "Nitrofurans",
                                 drug_class == "nitroimidazole antibiotic" ~ "Nitroimidazoles",
                                 drug_class == "nucleoside antibiotic" ~ "Nucleosides",
                                 drug_class == "oxazolidinone antibiotic" ~ "Oxazolidinones",
                                 drug_class == "penam" ~ "B-lactams",
                                 drug_class == "penem" ~ "B-lactams",
                                 drug_class == "peptide antibiotic" ~ "Peptide antibiotics",
                                 drug_class == "phenicol antibiotic" ~ "Phenicols",
                                 drug_class == "phosphonic acid antibiotic" ~ "Phosphonic acid antibiotics",
                                 drug_class == "pleuromutilin antibiotic" ~ "Pleuromutilins",
                                 drug_class == "rifamycin antibiotic" ~ "Ansamycins",
                                 drug_class == "streptogramin A antibiotic" ~ "Streptogramins",
                                 drug_class == "streptogramin antibiotic" ~ "Streptogramins",
                                 drug_class == "streptogramin B antibiotic" ~ "Streptogramins",
                                 drug_class == "sulfonamide antibiotic" ~ "Sulfonamides",
                                 drug_class == "sulfone antibiotic" ~ "Sulfones"))

CARDABX_df = melt(AMR_genes_card_annotation_CARD_ID_drugStrat_Action, id='ABX_Class')
CARDABX_df$species = metadata$species[match(CARDABX_df$variable,rownames(metadata))]
CARDABX_df$value = as.numeric(CARDABX_df$value)
CARDABX_df = aggregate(value ~ ABX_Class + variable + species, data=CARDABX_df, sum)

CARDABX_df_log = CARDABX_df
CARDABX_df_log[CARDABX_df_log==0] = min(CARDABX_df_log$value[CARDABX_df_log$value>0])/10
CARDABX_df_log$value = log10(CARDABX_df_log$value)
CARDABX_df_log$value = as.numeric(CARDABX_df_log$value)

top_abx = c('Tetracyclines','Lincosamides','Macrolides','B-lactams','Aminoglycosides','Streptogramins','Quinolones')

####################################################################
### #Figure 6B boxplots and supplemental figure@@@ full boxplots ###
####################################################################
proportion_zeros = CARDABX_df %>%
  dplyr::group_by(ABX_Class,species) %>% 
  dplyr::summarise(prop_0 = sum(value==0)/dplyr::n())

proportion_zeroes = ggplot(proportion_zeros, aes(x=reorder(factor(ABX_Class),-prop_0), y=prop_0, fill = factor(species)))+
  geom_bar(position="dodge", stat="identity",width = 0.60)+
  theme( legend.position = "none" ) +
  coord_flip() +
  scale_fill_manual(values=c(cat="indianred",dog="#E69F00",human="#56B4E9")) +
  ylab("Proportion of zeroes") +
  xlab("") +
  theme_light() +
  theme(legend.position="none") +
  theme(text = element_text(size = 20)) +
  scale_y_continuous(limits = c(0,1),breaks = c(0.0,0.5,1.0))

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/ABX_proportion_zeros.pdf",width = 2,height = 20)
proportion_zeroes
dev.off()

CARDABX_df_log_new = CARDABX_df
CARDABX_df_log_new = CARDABX_df_log_new[CARDABX_df_log_new$value!=0,]

CARDABX_df_log_new$value = log10(CARDABX_df_log_new$value)
CARDABX_df_log_new$value = as.numeric(CARDABX_df_log_new$value)

levels = c("Tetracyclines", "Lincosamides", "Macrolides","B-lactams","Aminoglycosides",
           "Streptogramins","Phenicols","Diaminopyrimidines","Nucleosides","Peptide antibiotics",
           "Ansamycins","Quinolones","Disinfecting agents and antiseptics","Pleuromutilins",
           "Aminocoumarins","Nitroimidazoles","Phosphonic acid antibiotics","Glycopeptides",
           "Sulfones","Sulfonamides","Oxazolidinones","Nitrofurans","Fusidanes")
levels = rev(levels)

CARDABX_df_log_new$ABX_Class <- factor(CARDABX_df_log_new$ABX_Class, levels=levels)

ABX_revised = ggplot(CARDABX_df_log_new, aes(x=ABX_Class, y=value, color = factor(species)))+
  geom_boxplot(lwd=1) +
  theme( legend.position = "none" ) +
  coord_flip() +
  scale_color_manual(values=c(cat="indianred",dog="#E69F00",human="#56B4E9")) +
  ylab("log10(relative abundance)") +
  xlab("") +
  theme_light() +
  theme(legend.position="none") +
  theme(text = element_text(size = 20))

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/ABX_target_generalClasses_Nozeros.pdf",width = 6,height = 10)
ABX_revised
dev.off()

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/ABX_revised_fig.pdf",width =16,height = 18)
ggpubr::ggarrange(proportion_zeroes, ABX_revised + theme(axis.text.y = element_blank(),axis.ticks.y = element_blank(),axis.title.y = element_blank() ), nrow = 1,widths = c(0.75, 1))
dev.off()

#revised truncated
proportion_zeros_trun = proportion_zeros[proportion_zeros$ABX_Class %in% top_abx,]
CARDABX_df_log_new_trun = CARDABX_df_log_new[CARDABX_df_log_new$ABX_Class %in% top_abx,]

proportion_zeroes_trun = ggplot(proportion_zeros_trun, aes(x=reorder(factor(ABX_Class),-prop_0), y=prop_0, fill = factor(species)))+
  geom_bar(position="dodge", stat="identity",width = 0.60)+
  theme( legend.position = "none" ) +
  coord_flip() +
  scale_fill_manual(values=c(cat="indianred",dog="#E69F00",human="#56B4E9")) +
  ylab("Proportion of zeroes") +
  xlab("") +
  theme_light() +
  theme(legend.position="none") +
  theme(text = element_text(size = 20)) +
  scale_y_continuous(limits = c(0,1),breaks = c(0.0,0.5,1.0))

ABX_revised_trun = ggplot(CARDABX_df_log_new_trun, aes(x=ABX_Class, y=value, color = factor(species)))+
  geom_boxplot(lwd=1) +
  theme( legend.position = "none" ) +
  coord_flip() +
  scale_color_manual(values=c(cat="indianred",dog="#E69F00",human="#56B4E9")) +
  ylab("log10(relative abundance)") +
  xlab("") +
  theme_light() +
  theme(legend.position="none") +
  theme(text = element_text(size = 20))

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/ABX_revised_truncated_fig.pdf",width =8,height = 8)
ggpubr::ggarrange(proportion_zeroes_trun, ABX_revised_trun + theme(axis.text.y = element_blank(),axis.ticks.y = element_blank(),axis.title.y = element_blank() ), nrow = 1,widths = c(0.75, 1))
dev.off()

CARDABX_df_pivot = dcast(data = CARDABX_df,formula = ABX_Class~variable,fun.aggregate = sum,value.var = "value")
rownames(CARDABX_df_pivot) = CARDABX_df_pivot$ABX_Class
CARDABX_df_pivot$ABX_Class = NULL

#maaslin for abx targets
Maaslin2(CARDABX_df_pivot,metadata_for_amr_adonis,output = "/Users/tobynbranck/Documents/pets_meta/maaslin_pets_HostsStrat_hmpRef_ABXtargets_superclasses",fixed_effects = c("species"),reference=c("species,human"), random_effects = c("study_readable"))
Maaslin2(CARDABX_df_pivot,metadata_for_amr_adonis,output = "/Users/tobynbranck/Documents/pets_meta/maaslin_pets_HostsStrat_dogRef_ABXtargets_superclasses",fixed_effects = c("species"),reference=c("species,dog"), random_effects = c("study_readable"))
Maaslin2(CARDABX_df_pivot,metadata_for_amr_adonis,output = "/Users/tobynbranck/Documents/pets_meta/maaslin_pets_HostsStrat_catRef_ABXtargets_superclasses",fixed_effects = c("species"),reference=c("species,cat"), random_effects = c("study_readable"))

#individual AMR gene boxplots
maaslin_df = as.data.frame(t(AMR_genes_filtered_maas))
maaslin_df$samples = rownames(maaslin_df)
maaslin_df = melt(maaslin_df)
maaslin_df$species = metadata$species[match(maaslin_df$sample,rownames(metadata))]

###### Individual gene distributions (Supplemental Figure @@@) #########
#Example: UniRef90_P22782: Chloramphenicol acetyltransferase
P22782_df = maaslin_df[maaslin_df$variable == 'UniRef90_P22782: Chloramphenicol acetyltransferase',]

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/UniRef90_P22782_Campylobacter.pdf",width = 6,height = 6)
ggplot(P22782_df, mapping= aes(x = variable, y = value))+
  geom_boxplot(aes(color = species), outlier.shape = NA ) +
  geom_point(aes(color= species), alpha = 0.5, size=4,
             position = position_jitterdodge(jitter.width = 0.1)) +
  scale_color_manual(values=c(cat="indianred",dog="#E69F00",human="#56B4E9")) +
  xlab("") +
  ylab("Relative abundance") +
  ggtitle("UniRef90_P22782: Chloramphenicol acetyltransferase \nCARD annotation: Campylobacter coli chloramphenicol acetyltransferase") +
  theme_classic() +
  theme(legend.position="none") +
  scale_y_continuous(labels = function(x) format(x, scientific = TRUE))
dev.off()

### BUG contributions to certain genes ("new vignettes")
#Campylobacter resistance vignette
#Uniref90 P22782: chloramphenicol acetelytransferase (carried by Campylobacter)
P22782_stratified_df = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/genes_from_strat_table/Uniref90_P22782_stratified_relab_gene_fams.tsv", header=T, check.names = F))
P22782_stratified_df = melt(P22782_stratified_df, id = '# Gene Family')
names(P22782_stratified_df) = c('names','sample','value')
P22782_stratified_df = P22782_stratified_df[!P22782_stratified_df$value ==0,]

P22782_stratified_df$sample = gsub('_Abundance-RPKs','',P22782_stratified_df$sample)
P22782_stratified_df$sample = gsub('-','.',P22782_stratified_df$sample)
P22782_stratified_df = P22782_stratified_df[!P22782_stratified_df$sample %in% madagascar_samps,]
P22782_stratified_df$host = metadata$species[match(P22782_stratified_df$sample,metadata$sample_id)]

numColors <- length(unique(P22782_stratified_df$host)) # How many colors you need
getColors <- scales::brewer_pal('qual') # Create a function that takes a number and returns a qualitative palette of that length (from the scales package)
myPalette <- getColors(numColors)
myPalette = c("#E69F00","#56B4E9","indianred")
names(myPalette) <- unique(P22782_stratified_df$host) # Give every color an appropriate name
P22782_stratified_df$color = myPalette[match(P22782_stratified_df$host,names(myPalette))]
P22782_stratified_df = P22782_stratified_df[order(P22782_stratified_df$value,decreasing = TRUE),]

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/UniRef90_P22782_BugContributions.pdf",width = 10,height = 6)
ggplot(P22782_stratified_df, aes(fill=names, y=value, x=reorder(sample,-value,sum))) + 
  geom_bar(position="stack", stat="identity") + 
  theme_classic() +
  theme(axis.text.x = element_text(colour=P22782_stratified_df$color,angle = 90, vjust = 0.5, hjust=1,size = 4.5)) +
  scale_y_continuous(expand = c(0, 0)) +
  xlab("") +
  ylab("log10(Relative abundance") +
  #scale_fill_manual(values=c("darkslategrey","azure4","bisque1")) +
  ggtitle("UniRef90 P22782: Chloramphenicol acetyltransferase \nCARD: chloramphenicol acetyltransferase (CAT)") +
  theme(legend.position=c(.75,.5))
dev.off()

#Uniref90 A0A2S1CWY0: OXA-61 family class D beta-lactamase OXA-659
A0A2S1CWY0_stratified_df = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/genes_from_strat_table/Uniref90_A0A2S1CWY0_stratified_relab_gene_fams.tsv", header=T, check.names = F))
A0A2S1CWY0_stratified_df = melt(A0A2S1CWY0_stratified_df, id = '# Gene Family')
names(A0A2S1CWY0_stratified_df) = c('names','sample','value')
A0A2S1CWY0_stratified_df = A0A2S1CWY0_stratified_df[!A0A2S1CWY0_stratified_df$value ==0,]

A0A2S1CWY0_stratified_df$sample = gsub('_Abundance-RPKs','',A0A2S1CWY0_stratified_df$sample)
A0A2S1CWY0_stratified_df$sample = gsub('-','.',A0A2S1CWY0_stratified_df$sample)
A0A2S1CWY0_stratified_df = A0A2S1CWY0_stratified_df[!A0A2S1CWY0_stratified_df$sample %in% madagascar_samps,]
A0A2S1CWY0_stratified_df$host = metadata$species[match(A0A2S1CWY0_stratified_df$sample,metadata$sample_id)]

numColors <- length(unique(A0A2S1CWY0_stratified_df$host)) # How many colors you need
getColors <- scales::brewer_pal('qual') # Create a function that takes a number and returns a qualitative palette of that length (from the scales package)
myPalette <- getColors(numColors)
myPalette = c("#E69F00","#56B4E9","indianred")
names(myPalette) <- unique(A0A2S1CWY0_stratified_df$host) # Give every color an appropriate name
A0A2S1CWY0_stratified_df$color = myPalette[match(A0A2S1CWY0_stratified_df$host,names(myPalette))]
A0A2S1CWY0_stratified_df = A0A2S1CWY0_stratified_df[order(A0A2S1CWY0_stratified_df$value,decreasing = TRUE),]

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/UniRef90_A0A2S1CWY0_BugContributions.pdf",width = 4,height = 5)
ggplot(A0A2S1CWY0_stratified_df, aes(fill=names, y=(value), x=reorder(sample,value,sum))) + 
  geom_bar(position="stack", stat="identity",width = .5) + 
  theme_classic() +
  theme(axis.text.y = element_text(colour=A0A2S1CWY0_stratified_df$color, vjust = 0.5, hjust=1,size = 6)) +
  scale_y_continuous(expand = c(0, 0)) +
  xlab("") +
  ylab("Relative abundance") +
  scale_fill_manual(values=c("palevioletred4","pink1","wheat3")) +
  ggtitle("UniRef90 A0A2S1CWY0: OXA-61 family class D beta-lactamase OXA-659") +
  theme(legend.position=c(.75,.5)) + coord_flip()
dev.off()

#Uniref90 A0A1T1YUD0: cmeB Efflux pump membrane transporter
A0A1T1YUD0_stratified_df = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/genes_from_strat_table/Uniref90_A0A1T1YUD0_stratified_relab_gene_fams.tsv", header=T, check.names = F))
A0A1T1YUD0_stratified_df = melt(A0A1T1YUD0_stratified_df, id = '# Gene Family')
names(A0A1T1YUD0_stratified_df) = c('names','sample','value')
A0A1T1YUD0_stratified_df = A0A1T1YUD0_stratified_df[!A0A1T1YUD0_stratified_df$value ==0,]

A0A1T1YUD0_stratified_df$sample = gsub('_Abundance-RPKs','',A0A1T1YUD0_stratified_df$sample)
A0A1T1YUD0_stratified_df$sample = gsub('-','.',A0A1T1YUD0_stratified_df$sample)
A0A1T1YUD0_stratified_df = A0A1T1YUD0_stratified_df[!A0A1T1YUD0_stratified_df$sample %in% madagascar_samps,]
A0A1T1YUD0_stratified_df$host = metadata$species[match(A0A1T1YUD0_stratified_df$sample,metadata$sample_id)]

numColors <- length(unique(A0A1T1YUD0_stratified_df$host)) # How many colors you need
getColors <- scales::brewer_pal('qual') # Create a function that takes a number and returns a qualitative palette of that length (from the scales package)
myPalette <- getColors(numColors)
myPalette = c("#E69F00","#56B4E9","indianred")
names(myPalette) <- unique(A0A1T1YUD0_stratified_df$host) # Give every color an appropriate name
A0A1T1YUD0_stratified_df$color = myPalette[match(A0A1T1YUD0_stratified_df$host,names(myPalette))]
A0A1T1YUD0_stratified_df = A0A1T1YUD0_stratified_df[order(A0A1T1YUD0_stratified_df$value,decreasing = TRUE),]

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/UniRef90_A0A1T1YUD0_BugContributions.pdf",width = 7,height = 6)
ggplot(A0A1T1YUD0_stratified_df, aes(fill=names, y=value, x=reorder(sample,-value,sum))) + 
  geom_bar(position="stack", stat="identity") + 
  theme_classic() +
  theme(axis.text.x = element_text(colour=A0A1T1YUD0_stratified_df$color,angle = 90, vjust = 0.5, hjust=1,size = 6)) +
  scale_y_continuous(expand = c(0, 0)) +
  xlab("") +
  ylab("log10(Relative abundance") +
  scale_fill_manual(values=c("palevioletred4","pink1","wheat3")) +  
  ggtitle("UniRef90 A0A1T1YUD0: Efflux pump membrane transporter \nCARD: cmeB") +
  theme(legend.position=c(.75,.5))
dev.off()

#UniRef90_ rpoB (Supplemental Figure @@@)
Q8G3I2_stratified_df = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/genes_from_strat_table/Uniref90_Q8G3I2_stratified_relab_gene_fams.tsv", header=T, check.names = F))
Q8G3I2_stratified_df = melt(Q8G3I2_stratified_df, id = '# Gene Family')
names(Q8G3I2_stratified_df) = c('names','sample','value')
Q8G3I2_stratified_df = Q8G3I2_stratified_df[!Q8G3I2_stratified_df$value ==0,]

Q8G3I2_stratified_df$sample = gsub('_Abundance-RPKs','',Q8G3I2_stratified_df$sample)
Q8G3I2_stratified_df$sample = gsub('-','.',Q8G3I2_stratified_df$sample)
Q8G3I2_stratified_df = Q8G3I2_stratified_df[!Q8G3I2_stratified_df$sample %in% madagascar_samps,]
Q8G3I2_stratified_df$host = metadata$species[match(Q8G3I2_stratified_df$sample,metadata$sample_id)]

numColors <- length(unique(Q8G3I2_stratified_df$host)) # How many colors you need
getColors <- scales::brewer_pal('qual') # Create a function that takes a number and returns a qualitative palette of that length (from the scales package)
myPalette <- getColors(numColors)
myPalette = c("#E69F00","indianred","#56B4E9")
names(myPalette) <- unique(Q8G3I2_stratified_df$host) # Give every color an appropriate name
Q8G3I2_stratified_df$color = myPalette[match(Q8G3I2_stratified_df$host,names(myPalette))]
Q8G3I2_stratified_df = Q8G3I2_stratified_df[order(Q8G3I2_stratified_df$value,decreasing = TRUE),]

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/UniRef90_Q8G3I2_BugContributions.pdf",width = 10,height = 4)
ggplot(Q8G3I2_stratified_df, aes(fill=names, y=value, x=reorder(sample,-value,sum))) +
  geom_bar(position="stack", stat="identity") +
  theme_classic() +
  theme(axis.text.x = element_text(colour=Q8G3I2_stratified_df$color,angle = 90, vjust = 0.5, hjust=1,size = 4.5)) +
  scale_y_continuous(expand = c(0, 0)) +
  xlab("") +
  ylab("log10(Relative abundance)") +
  scale_fill_manual(values=c("darkslategrey","azure4","bisque2","azure2")) +
  ggtitle("UniRef90 Q8G3I2: isoleucine tRNA ligase") +
  theme(legend.position=c(.75,.5))
dev.off()

#UniRef90_Q8G3I2: isoleucine tRNA ligase (Supplemental Figure @@@)
Q8G3I2_stratified_df = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/genes_from_strat_table/Uniref90_Q8G3I2_stratified_relab_gene_fams.tsv", header=T, check.names = F))
Q8G3I2_stratified_df = melt(Q8G3I2_stratified_df, id = '# Gene Family')
names(Q8G3I2_stratified_df) = c('names','sample','value')
Q8G3I2_stratified_df = Q8G3I2_stratified_df[!Q8G3I2_stratified_df$value ==0,]

Q8G3I2_stratified_df$sample = gsub('_Abundance-RPKs','',Q8G3I2_stratified_df$sample)
Q8G3I2_stratified_df$sample = gsub('-','.',Q8G3I2_stratified_df$sample)
Q8G3I2_stratified_df = Q8G3I2_stratified_df[!Q8G3I2_stratified_df$sample %in% madagascar_samps,]
Q8G3I2_stratified_df$host = metadata$species[match(Q8G3I2_stratified_df$sample,metadata$sample_id)]

numColors <- length(unique(Q8G3I2_stratified_df$host)) # How many colors you need
getColors <- scales::brewer_pal('qual') # Create a function that takes a number and returns a qualitative palette of that length (from the scales package)
myPalette <- getColors(numColors)
myPalette = c("#E69F00","indianred","#56B4E9")
names(myPalette) <- unique(Q8G3I2_stratified_df$host) # Give every color an appropriate name
Q8G3I2_stratified_df$color = myPalette[match(Q8G3I2_stratified_df$host,names(myPalette))]
Q8G3I2_stratified_df = Q8G3I2_stratified_df[order(Q8G3I2_stratified_df$value,decreasing = TRUE),]

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/UniRef90_Q8G3I2_BugContributions.pdf",width = 10,height = 4)
ggplot(Q8G3I2_stratified_df, aes(fill=names, y=value, x=reorder(sample,-value,sum))) + 
  geom_bar(position="stack", stat="identity") + 
  theme_classic() +
  theme(axis.text.x = element_text(colour=Q8G3I2_stratified_df$color,angle = 90, vjust = 0.5, hjust=1,size = 4.5)) +
  scale_y_continuous(expand = c(0, 0)) +
  xlab("") +
  ylab("log10(Relative abundance)") +
  scale_fill_manual(values=c("darkslategrey","azure4","bisque2","azure2")) +
  ggtitle("UniRef90 Q8G3I2: isoleucine tRNA ligase") +
  theme(legend.position=c(.75,.5))
dev.off()

#UniRef90_P10738 ermB (found in Enterococcus spp., C. difficile, and R. gnavus)
P10738_stratified_df = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/Uniref90_P10738_stratified_relab_gene_fams.tsv", header=T, check.names = F))
P10738_stratified_df = melt(P10738_stratified_df, id = '# Gene Family')
names(P10738_stratified_df) = c('names','sample','value')
P10738_stratified_df = P10738_stratified_df[!P10738_stratified_df$value ==0,]

P10738_stratified_df$sample = gsub('_Abundance-RPKs','',P10738_stratified_df$sample)
P10738_stratified_df = P10738_stratified_df[!P10738_stratified_df$sample %in% madagascar_samps,]
P10738_stratified_df$host = metadata$species[match(P10738_stratified_df$sample,metadata$sample_id_metaphlan)]

numColors <- length(unique(P10738_stratified_df$host)) # How many colors you need
getColors <- scales::brewer_pal('qual') # Create a function that takes a number and returns a qualitative palette of that length (from the scales package)
myPalette <- getColors(numColors)
myPalette = c("#E69F00","indianred","#56B4E9")
names(myPalette) <- unique(P10738_stratified_df$host) # Give every color an appropriate name
P10738_stratified_df$color = myPalette[match(P10738_stratified_df$host,names(myPalette))]
P10738_stratified_df = P10738_stratified_df[order(P10738_stratified_df$value,decreasing = TRUE),]

P10738_stratified_df_sample_sums = aggregate(P10738_stratified_df$value, by=list(Category=P10738_stratified_df$sample), FUN=sum)
P10738_stratified_df_sample_sums = P10738_stratified_df_sample_sums[order(P10738_stratified_df_sample_sums$x,decreasing=TRUE),][1:100,]

P10738_stratified_df = P10738_stratified_df[P10738_stratified_df$sample %in% P10738_stratified_df_sample_sums$Category,]

P10738_stratified_df_Bug_sums = aggregate(P10738_stratified_df$value, by=list(Category=P10738_stratified_df$names), FUN=sum)
P10738_stratified_df_Bug_sums = P10738_stratified_df_Bug_sums[order(P10738_stratified_df_Bug_sums$x,decreasing=TRUE),][1:15,]

P10738_stratified_df$names[!P10738_stratified_df$names %in% P10738_stratified_df_Bug_sums$Category] <- "Other"

library(RColorBrewer)
# Define the number of colors you want
nb.cols <- 21
mycolors <- colorRampPalette(brewer.pal(8, "Set1"))(nb.cols)

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/UniRef90_P10738_BugContributions.pdf",width = 18,height = 8)
ggplot(P10738_stratified_df, aes(fill=names, y=value, x=reorder(sample,-value,sum))) + 
  geom_bar(position="stack", stat="identity") + 
  theme_classic() +
  #theme(axis.text.x = element_text(colour=P10738_stratified_df$color,angle = 90, vjust = 0.5, hjust=1,size = 4.5)) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1,size = 4.5)) +
  scale_y_continuous(expand = c(0, 0)) +
  xlab("") +
  ylab("Relative abundance") +
  scale_fill_manual(values=mycolors) +
  ggtitle("UniRef90 P10738: ermB") +
  theme(legend.position=c(.75,.5))
dev.off()

#################################################
##### shared, CA only, and unique AMR genes #####
#################################################
df_for_overlap = as.data.frame(t(AMR_genes_filtered_maas))
df_for_overlap$host = metadata$species[match(rownames(df_for_overlap),rownames(metadata))]
df_for_overlap$sample = rownames(df_for_overlap)
df_for_overlap = melt(df_for_overlap,id=c("sample","host"))

#count how many samples (by host) an gene has > 0 relative abundance
combined_prev_abund_filtering = aggregate(value ~ host + variable, df_for_overlap, function(x) sum(x > 0, na.rm = TRUE))

names(combined_prev_abund_filtering)[3] = 'number_greater_0.00001'
combined_prev_abund_filtering$prevalence = ifelse(combined_prev_abund_filtering$host=="dog",combined_prev_abund_filtering$number_greater_0.00001/2056 , ifelse(combined_prev_abund_filtering$host=="cat",combined_prev_abund_filtering$number_greater_0.00001/367, 
                                                                                                                                                               combined_prev_abund_filtering$number_greater_0.00001/238))
combined_prev_abund_filtering_filtered = combined_prev_abund_filtering[combined_prev_abund_filtering$number_greater_0.00001 >=3, ] 

combined_prev_abund_filtering_filtered_dcast = dcast(combined_prev_abund_filtering_filtered, variable ~ host,value.var='number_greater_0.00001')
combined_prev_abund_filtering_filtered_dcast$variable = as.character(combined_prev_abund_filtering_filtered_dcast$variable)

#venn diagram lists
cat_list = combined_prev_abund_filtering_filtered_dcast$variable[!is.na(combined_prev_abund_filtering_filtered_dcast$cat)]
dog_list = combined_prev_abund_filtering_filtered_dcast$variable[!is.na(combined_prev_abund_filtering_filtered_dcast$dog)]
human_list = combined_prev_abund_filtering_filtered_dcast$variable[!is.na(combined_prev_abund_filtering_filtered_dcast$human)]

library(ggVennDiagram)
library(sf)
cat_dog = intersect(cat_list,dog_list)
cat_human = intersect(cat_list,human_list)
dog_human = intersect(dog_list,human_list)
cat_dog_human = intersect(cat_dog,human_list)

x = list(cat=cat_list,dog=dog_list,human=human_list)

venn <- ggVennDiagram::Venn(x)
d <- process_data(venn)
d2 <- process_data(venn)

d2@region <- st_polygonize(d@setEdge)

col <- c(cat = "indianred", dog = "#E69F00", human = "#56B4E9")

cairo_pdf("v4_VENN_0.00001_atLeast3samples_AMRgenes.pdf",width = 5,height=5)
ggplot() +
  geom_sf(aes(fill = name), data = venn_region(d2)) +
  geom_sf(aes(color = name), data = venn_setedge(d)) +
  geom_sf_text(aes(label = name), data = venn_setlabel(d)) +
  geom_sf_text(aes(label = count), data = venn_region(d)) +
  scale_color_manual(values = ggplot2::alpha(col,.8)) +
  scale_fill_manual(values = ggplot2::alpha(col,.5)) +
  theme_void() +
  theme(legend.position = "none")
dev.off()

### plots for universally shared, companion animals only, host-specific; note - MEDIAN ABUNDANCE WHEN PRESENT
venn_data = process_data(venn)
test = as.data.frame(venn_region(venn_data))
shared_all = unlist(test$item[7])
shared_all_df = df_for_overlap[df_for_overlap$variable %in% shared_all,]
compan_animal_only = unlist(test$item[4])
compan_animal_only_df = df_for_overlap[df_for_overlap$variable %in% compan_animal_only,]
human_dog = unlist(test$item[6])
human_dog_df = df_for_overlap[df_for_overlap$variable %in% human_dog,]
human_cat = unlist(test$item[5])
human_cat_df = df_for_overlap[df_for_overlap$variable %in% human_cat,]
dog_ = unlist(test$item[2])
cat_ = unlist(test$item[1])
human_ = unlist(test$item[3])
uniques = c(dog_,cat_,human_)
unique_df = df_for_overlap[df_for_overlap$variable %in% uniques,]

### shared boxplots
shared_all_df$value[shared_all_df$value==0] = NA
shared_all_grouped = shared_all_df %>%
  dplyr::group_by(host, variable) %>%
  dplyr::summarise(median_abundance = median(value, na.rm=TRUE))
shared_all_grouped = as.data.frame(shared_all_grouped)

ggplot(shared_all_grouped, aes(x=reorder(variable,-median_abundance), y=log10(median_abundance),color=host)) + 
  geom_point() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1)) +
  xlab("") +
  scale_color_manual(values = c("cat" = "indianred",
                                "dog"="#E69F00",
                                "human"="#56B4E9")) +
  theme(legend.position="none")

shared_all_grouped_trunc = shared_all_grouped %>%
  dplyr::group_by(variable) %>%
  dplyr::summarise(max_median = max(median_abundance))
shared_all_grouped_trunc = as.data.frame(shared_all_grouped_trunc)
shared_all_grouped_trunc = shared_all_grouped_trunc[order(shared_all_grouped_trunc$max_median,decreasing=TRUE),]
#shared_all_grouped_trunc = shared_all_grouped_trunc %>% slice(1:15)
shared_all_grouped_trunc = as.data.frame(shared_all_grouped_trunc)
rownames(shared_all_grouped_trunc) = shared_all_grouped_trunc$variable

shared_all_grouped_trunc20 = shared_all_grouped[shared_all_grouped$variable %in% shared_all_grouped_trunc$variable,] 

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/shared_all_hosts_AMRgenes.pdf",width=10,height=16)
ggplot(shared_all_grouped_trunc20, aes(x=reorder(variable,median_abundance), y=log10(median_abundance),color=host)) + 
  geom_point(size=5,alpha=.6) +
  xlab("") +
  coord_flip() +
  scale_color_manual(values = c("cat" = "indianred",
                                "dog"="#E69F00",
                                "human"="#56B4E9")) +
  scale_y_continuous(limits=c(-8,-3.5)) +
  theme(legend.position=c(.8,.15)) +
  theme(axis.text = element_text(size = 12,family = 'Arial'))
dev.off()

### companion animal shared boxplots
compan_animal_only_df$value[compan_animal_only_df$value==0] = NA
compan_animal_only_df = compan_animal_only_df[!compan_animal_only_df$host == "human",]
compan_animal_only_grouped = compan_animal_only_df %>%
  dplyr::group_by(host, variable) %>%
  dplyr::summarise(median_abundance = median(value, na.rm=TRUE))
compan_animal_only_grouped = as.data.frame(compan_animal_only_grouped)

ggplot(compan_animal_only_grouped, aes(x=reorder(variable,-median_abundance), y=log10(median_abundance),color=host)) + 
  geom_point() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1)) +
  xlab("") +
  scale_color_manual(values = c("cat" = "indianred",
                                "dog"="#E69F00",
                                "human"="#56B4E9")) +
  theme(legend.position="none")

compan_animal_only_grouped_trunc = compan_animal_only_grouped %>%
  dplyr::group_by(variable) %>%
  dplyr::summarise(max_median = max(median_abundance))
compan_animal_only_grouped_trunc = as.data.frame(compan_animal_only_grouped_trunc)
compan_animal_only_grouped_trunc = compan_animal_only_grouped_trunc[order(compan_animal_only_grouped_trunc$max_median,decreasing=TRUE),]

#compan_animal_only_grouped_trunc = compan_animal_only_grouped_trunc %>% slice(1:100)
compan_animal_only_grouped_trunc = as.data.frame(compan_animal_only_grouped_trunc)
rownames(compan_animal_only_grouped_trunc) = compan_animal_only_grouped_trunc$variable

compan_animal_only_grouped_trunc20 = compan_animal_only_grouped[compan_animal_only_grouped$variable %in% compan_animal_only_grouped_trunc$variable,] 

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/CompAnim_shared_hosts_AMRgenes.pdf",width=10,height=5)
ggplot(compan_animal_only_grouped_trunc20, aes(x=reorder(variable,median_abundance), y=log10(median_abundance),color=host)) + 
  geom_point(size=5,alpha=.6) +
  xlab("") +
  coord_flip() +
  scale_color_manual(values = c("cat" = "indianred",
                                "dog"="#E69F00",
                                "human"="#56B4E9")) +
  scale_y_continuous(limits=c(-7,-4)) +
  theme(legend.position=c(.8,.15)) +
  theme(axis.text = element_text(size = 10,family = 'Arial'))
dev.off()

### unique species plots
unique_df$value[unique_df$value==0] = NA
unique_df = unique_df[!(unique_df$variable %in% dog_ & unique_df$host == "human"),]
unique_df = unique_df[!(unique_df$variable %in% dog_ & unique_df$host == "cat"),]

unique_df = unique_df[!(unique_df$variable %in% cat_ & unique_df$host == "human"),]
unique_df = unique_df[!(unique_df$variable %in% cat_ & unique_df$host == "dog"),]

unique_df = unique_df[!(unique_df$variable %in% human_ & unique_df$host == "dog"),]
unique_df = unique_df[!(unique_df$variable %in% human_ & unique_df$host == "cat"),]

unique_grouped = unique_df %>%
  dplyr::group_by(host, variable) %>%
  dplyr::summarise(median_abundance = median(value, na.rm=TRUE))
unique_grouped = as.data.frame(unique_grouped)

unique_grouped_trunc = unique_grouped %>%
  dplyr::group_by(host,variable) %>%
  dplyr::summarise(max_median = max(median_abundance))
unique_grouped_trunc = as.data.frame(unique_grouped_trunc)

unique_grouped_trunc = unique_grouped_trunc %>% dplyr::group_by(host) %>% dplyr::arrange(desc(max_median),.by_group = TRUE) %>% top_n(30,max_median)
unique_grouped_trunc30 = unique_grouped[unique_grouped$variable %in% unique_grouped_trunc$variable,]
unique_grouped_trunc30 = as.data.frame(unique_grouped_trunc30)
rownames(unique_grouped_trunc30) = unique_grouped_trunc30$variable

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/unique_AMRgenes.pdf",width=10,height=12)
ggplot(unique_grouped_trunc30, aes(x=reorder(variable,median_abundance), y=log10(median_abundance),color=host)) + 
  geom_point(size=5,alpha=.6) +
  xlab("") +
  coord_flip() +
  scale_color_manual(values = c("cat" = "indianred",
                                "dog"="#E69F00",
                                "human"="#56B4E9")) +
  scale_y_continuous(limits=c(-7.5,-4)) +
  theme(legend.position=c(.8,.15)) +
  theme(axis.text = element_text(size = 10,family = 'Arial'))
dev.off()

shared_plot = ggplot(shared_all_grouped_trunc20, aes(x=reorder(variable,median_abundance), y=log10(median_abundance),color=host)) + 
  geom_point(size=4,alpha=.6) +
  theme(axis.text.x = element_text(angle = 90, vjust = 1, hjust=1)) +
  xlab("") +
  scale_color_manual(values = c("cat" = "indianred",
                                "dog"="#E69F00",
                                "human"="#56B4E9")) +
  scale_y_continuous(limits=c(-7,-3.5)) +
  theme_bw() +
  ylab("") +
  coord_flip() +
  theme(legend.position="none",
        axis.text.x = element_blank(),
        axis.ticks.x = element_blank())

ca_plot = ggplot(compan_animal_only_grouped_trunc20, aes(x=reorder(variable,median_abundance), y=log10(median_abundance),color=host)) + 
  geom_point(size=4,alpha=.6) +
  theme(axis.text.x = element_text(angle = 90, vjust = 1, hjust=1)) +
  xlab("") +
  scale_color_manual(values = c("cat" = "indianred",
                                "dog"="#E69F00",
                                "human"="#56B4E9")) +
  scale_y_continuous(limits=c(-7,-3.5)) +
  theme_bw() +
  ylab("") +
  coord_flip() +
  theme(legend.position="none",
        axis.text.x = element_blank(),
        axis.ticks.x = element_blank()) 

unique_plot = ggplot(unique_grouped_trunc30, aes(x=reorder(variable,median_abundance), y=log10(median_abundance),color=host)) + 
  geom_point(size=4,alpha=.6) +
  theme(axis.text.x = element_text(angle = 90, vjust = 1, hjust=1)) +
  xlab("") +
  scale_color_manual(values = c("cat" = "indianred",
                                "dog"="#E69F00",
                                "human"="#56B4E9")) +
  scale_y_continuous(limits=c(-7,-3.5)) +
  theme_bw() +
  coord_flip() +
  theme(legend.position="none")

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/AMR_Shared_Unique_panel.pdf",width = 8,height = 10)
cowplot::plot_grid(shared_plot,ca_plot,unique_plot,nrow=3,ncol = 1,align='hv',hjust = )
dev.off()

#################################
## ABX diversity in commensals ##
#################################
meta_for_MAD_samps = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/metadata_for_AMR_analysis.csv", header=T, check.names = F))
metadata = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/all_metadata_preformatted.csv", header=T, check.names = F))
strat = as.data.frame(data.table::fread("/Users/tobynbranck/Documents/pets_meta/ALL_SAMPS_joined_genefams_relab_stratified_AMR_only_concat.tsv", header=T, check.names = F))
rownames(strat) = strat$'# Gene Family'
strat$'# Gene Family' = NULL
colnames(strat) = gsub("_Abundance-RPKs","",colnames(strat))

rownames(metadata) = metadata$sample_id_metaphlan
dog_samps = rownames(metadata)[metadata$species=="dog"]
cat_samps = rownames(metadata)[metadata$species=="cat"]
human_samps = rownames(metadata)[metadata$species=="human"]
hmp1_II_samps = rownames(metadata)[metadata$study_readable=="HMP1-II"]
madagascar_samps = meta_for_MAD_samps$V1[meta_for_MAD_samps$study_readable=='Madagascar']

# remove madagascar samples
metadata = metadata[!metadata$study_readable=="Madagascar",]
strat = strat[,colnames(strat) %in% rownames(metadata)]

strat = strat[, colSums(strat != 0) > 0]
strat = strat[rowSums(strat !=0)>0,]
strat$uniref_ID = gsub("\\|.*","",rownames(strat))
strat$bug = gsub(".*\\|","",rownames(strat))
strat$bug = gsub(".*\\.s__","",strat$bug)
strat = strat[!strat$bug=='unclassified',]
strat = strat[strat$uniref_ID %in% card_uniprot_align$uniref_ID,]
strat$drug_class = AMR_genes_card_annotation_CARD_ID_drugStrat_Action$ABX_Class[match(strat$uniref_ID,AMR_genes_card_annotation_CARD_ID$uniref90)]

dog_strat = strat[,colnames(strat) %in% dog_samps]
cat_strat = strat[,colnames(strat) %in% cat_samps]
hmp_strat = strat[,colnames(strat) %in% hmp1_II_samps]

cat_strat$uniref_ID = gsub("\\|.*","",rownames(cat_strat))
cat_strat$bug = gsub(".*\\|","",rownames(cat_strat))
cat_strat$bug = gsub(".*\\.s__","",cat_strat$bug)
cat_strat$CARD = card_uniprot_align$CARD_ID[match(cat_strat$uniref_ID,card_uniprot_align$uniref_ID)]

hmp_strat$uniref_ID = gsub("\\|.*","",rownames(hmp_strat))
hmp_strat$bug = gsub(".*\\|","",rownames(hmp_strat))
hmp_strat$bug = gsub(".*\\.s__","",hmp_strat$bug)

strat_melted = melt(strat, id.vars = c("bug","drug_class","uniref_ID"), variable.name = "sample")
strat_melted$host = metadata$species[match(strat_melted$sample,metadata$sample_id_metaphlan)]
strat_melted$value = as.numeric(strat_melted$value)
strat_averaged = strat_melted %>%
  dplyr::group_by(bug,host,drug_class) %>% 
  summarise_at(vars("value"), funs(mean, sd, se=sd(.)/sqrt(n())))

strat_melted$value_log = asin(sqrt(as.numeric(strat_melted$value)))
strat_melted$value_log[strat_melted$value_log == -Inf] <- 0

strat_averaged_logged = strat_melted %>%
  dplyr::group_by(bug,host,drug_class) %>% 
  summarise_at(vars("value_log"), funs(mean, sd, se=sd(.)/sqrt(n())))

### For AMR figure ###
# this filtering removes bugs if all three hosts do not have any ARGs > 0
strat_average_filter = strat_averaged %>% dplyr::group_by(bug,host) %>% filter(any(mean != 0)) %>% ungroup()

strat_average_filter_logged = strat_averaged_logged %>% dplyr::group_by(bug,host) %>% filter(any(mean != 0)) %>% ungroup()
strat_average_filter_logged = strat_average_filter_logged %>%  dplyr::group_by(bug) %>% 
  filter(length(unique(host)) == 3)

strat_averaged_ARGcount = strat_average_filter %>% filter(mean > 0) %>%
  dplyr::group_by(bug,host) %>% 
  dplyr::summarise(distinct_ARGs = n_distinct(drug_class))
strat_averaged_ARGTOTAL = strat_average_filter %>% filter(mean > 0) %>%
  dplyr::group_by(bug) %>% 
  dplyr::summarise(ARGs_total = n_distinct(drug_class))
strat_averaged_ARGcount = strat_averaged_ARGcount[order(strat_averaged_ARGcount$distinct_ARGs, decreasing = TRUE), ]
strat_averaged_ARGTOTAL = strat_averaged_ARGTOTAL[order(strat_averaged_ARGTOTAL$ARGs_total, decreasing = TRUE), ]

strat_averaged_ARGcount_plot = strat_averaged_ARGcount[strat_averaged_ARGcount$bug %in% strat_averaged_ARGTOTAL$bug[1:119],]
strat_averaged_ARGcount_plot$bug = gsub("_"," ",strat_averaged_ARGcount_plot$bug)
cairo_pdf("/Users/tobynbranck/Documents/pets_meta/NumberARGs_perBug.pdf",width=5,height=14)
ggplot(strat_averaged_ARGcount_plot, aes(host, reorder(bug,distinct_ARGs), fill= distinct_ARGs)) + 
  geom_tile() +
  scale_fill_gradient(low="white", high="red") +
  xlab("") +
  ylab("") +
  theme(axis.text.y = element_text(face = "italic",family="Arial", size=8))
dev.off()

strat_averaged_variety = strat_averaged %>% ungroup() %>% filter(grepl('Bacteroides_uniformis|Bacteroides_coprocola|Bacteroides_vulgatus|Blautia_producta|Bifidobacterium_adolescentis|Bifidobacterium_pseudolongum|Prevotella_copri|Collinsella_stercoris|Megaspaera_elsdenii|Enterococcus_hirae',strat_averaged$bug))
strat_averaged_variety_logged = strat_averaged_logged %>% ungroup() %>% filter(grepl('Bacteroides_uniformis|Bacteroides_coprocola|Bacteroides_vulgatus|Blautia_producta|Bifidobacterium_adolescentis|Bifidobacterium_pseudolongum|Prevotella_copri|Collinsella_stercoris|Megaspaera_elsdenii|Enterococcus_hirae',strat_averaged_logged$bug))

error_bars = strat_averaged_variety %>%
  arrange(bug,host,desc(drug_class)) %>%
  # for each cyl group, calculate new value by cumulative sum
  dplyr::group_by(bug,host) %>%
  mutate(mean_hp_new = cumsum(mean)) %>%
  ungroup()

error_bars_logged = strat_averaged_variety_logged %>%
  arrange(bug,host,desc(drug_class)) %>%
  # for each cyl group, calculate new value by cumulative sum
  dplyr::group_by(bug,host) %>%
  mutate(mean_hp_new = cumsum(mean)) %>%
  ungroup()

colourCount = length(unique(strat_averaged_variety$drug_class))
getPalette = colorRampPalette(RColorBrewer::brewer.pal(9, "Set1"))
cairo_pdf("/Users/tobynbranck/Documents/pets_meta/commensal_ARG_diversity_raw_se.pdf",width = 14,height=4)
ggplot(strat_averaged_variety, aes(x = host, y = mean, fill = drug_class)) +
  geom_col(color="black", width=0.6) +
  theme_classic() +
  scale_fill_manual(values=getPalette(colourCount)) +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1)) +
  geom_errorbar(data = error_bars,
                aes(x = host, ymax = mean_hp_new + se, ymin = mean_hp_new), 
                width = 0.2) +
  facet_wrap(.~bug,scales = "free_y",nrow=1)
dev.off()

cairo_pdf("/Users/tobynbranck/Documents/pets_meta/commensal_ARG_diversity_mostARGs.pdf",width = 16,height=6)
ggplot(strat_averaged_variety, aes(x = host, y = mean, fill = drug_class)) +
  geom_col(color="black", width=0.6) +
  theme_classic() +
  scale_fill_manual(values=getPalette(colourCount)) +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1)) +
  facet_wrap(.~bug,scales = "free_y",nrow=1)
dev.off()

colourCount = length(unique(strat_averaged_variety$drug_class))
getPalette = colorRampPalette(RColorBrewer::brewer.pal(9, "Set1"))
cairo_pdf("/Users/tobynbranck/Documents/pets_meta/commensal_ARG_diversity.pdf",width = 12,height=5)
ggplot(strat_averaged_variety, aes(x = host, y = mean, fill = drug_class)) + 
  geom_bar(position = "fill",stat = "identity",color="black", width=0.8) +
  theme_classic() +
  scale_fill_manual(values=getPalette(colourCount)) +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1)) +
  ylab("Proportion AMR") +
  xlab("") +
  facet_grid(.~bug)
dev.off()