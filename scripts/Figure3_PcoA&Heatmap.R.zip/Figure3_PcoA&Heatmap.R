### Pet's pooled study: Figure 3 ###
### Last Edit: 11/12/23 ###

# rm(list = ls())

#######################################################################################################################################
## packages
library(tidyverse)
library(vegan)
library(ggplot2)
library(shadowtext)
library(ComplexHeatmap)
library(viridis)
library(gridExtra)
library(cowplot)
library(grid)
library(Maaslin2)

#######################################################################################################################################
## Filter metaphlan table on SGB level
# input
animal = read_tsv('Taxonomic profiling/metaphlanv4/metaphlan_taxonomic_animal_profiles.tsv')
human_HMP = read_tsv('Taxonomic profiling/metaphlanv4/metaphlan_taxonomic_human_profiles.tsv')
human_MAD = read.csv('Taxonomic profiling/human/CM_madagascar__metaphlan-4.0.4_vOct22_CHOCOPhlAnSGB_202212.tsv', skip = 1, head = TRUE, sep = "\t")

# remove subject with UNKNOWN = 100
animal_df = animal[sapply(animal, function(x) x[4] != 100)] # 0 people with 100
human_HMP_df = human_HMP[sapply(human_HMP, function(x) x[3] != 100)] # 0 people with 100
human_MAD_df = human_MAD[sapply(human_MAD, function(x) x[3432] != 100)] # 3 people with 100

# rename subject name
colnames(animal_df) = gsub("_taxonomic_profile", "", colnames(animal_df))
colnames(human_HMP_df) = gsub("_taxonomic_profile", "", colnames(human_HMP_df))

# select unknown 
unknown_animal = animal_df[4,]
unknown_human_HMP = human_HMP_df[3,]
unknown_human_MAD = human_MAD_df[3432,]

# keep only the rows with species information 
animal_df = animal_df[grepl('t__', animal_df$`# taxonomy`),] 
animal_df = animal_df[!grepl("k__Viruses", animal_df$`# taxonomy`),]
animal_df = animal_df[!grepl("k__Archaea", animal_df$`# taxonomy`),]
animal_df = animal_df[!grepl("k__Eukaryota", animal_df$`# taxonomy`),]

human_HMP_df = human_HMP_df[grepl('t__', human_HMP_df$`# taxonomy`),] 
human_HMP_df = human_HMP_df[!grepl("k__Viruses", human_HMP_df$`# taxonomy`),]
human_HMP_df = human_HMP_df[!grepl("k__Archaea", human_HMP_df$`# taxonomy`),]
human_HMP_df = human_HMP_df[!grepl("k__Eukaryota", human_HMP_df$`# taxonomy`),]

human_MAD_df = human_MAD_df[grepl('t__', human_MAD_df$`clade_name`),] 
human_MAD_df = human_MAD_df[!grepl("k__Viruses", human_MAD_df$`clade_name`),]
human_MAD_df = human_MAD_df[!grepl("k__Archaea", human_MAD_df$`clade_name`),]
human_MAD_df = human_MAD_df[!grepl("k__Eukaryota", human_MAD_df$`clade_name`),]

# rbind back unknown row
animal_df = rbind(unknown_animal, animal_df)
human_HMP_df = rbind(unknown_human_HMP, human_HMP_df)
human_MAD_df = rbind(unknown_human_MAD, human_MAD_df)

# put the values on a 0-1 scale (divide by 100)
animal_df = cbind(animal_df$`# taxonomy`, animal_df[, 2:ncol(animal_df)]/100) 
colnames(animal_df)[colnames(animal_df) == 'animal_df$`# taxonomy`'] <- 'clade_name'

human_HMP_df = cbind(human_HMP_df$`# taxonomy`, human_HMP_df[, 2:ncol(human_HMP_df)]/100) 
colnames(human_HMP_df)[colnames(human_HMP_df) == 'human_HMP_df$`# taxonomy`'] <- 'clade_name'

human_MAD_df = cbind(human_MAD_df$`clade_name`, human_MAD_df[, 2:ncol(human_MAD_df)]/100) 
colnames(human_MAD_df)[colnames(human_MAD_df) == 'human_MAD_df$clade_name'] <- 'clade_name'

#normalized
animal_species = animal_df[-1,]
animal_species[, -1] = lapply(animal_species[, -1], function(x) x/sum(x)) # save as 'Taxonomic profiling/metaphlanv4/merged_taxonomic_SGB_animal_profile_normalized.csv'

human_HMP_species = human_HMP_df[-1,]
human_HMP_species[, -1] = lapply(human_HMP_species[, -1], function(x) x/sum(x)) # save as 'Taxonomic profiling/metaphlanv4/merged_taxonomic_SGB_human_profile_normalized.csv'

human_MAD_species = human_MAD_df[-1,]
human_MAD_species[, -1] = lapply(human_MAD_species[, -1], function(x) x/sum(x)) # save as 'Taxonomic profiling/metaphlanv4/merged_taxonomic_SGB_MAD_human_profile_normalized.csv'

#######################################################################################################################################
## Prepare Data for Analysis
# input
animal = animal_species 
rownames(animal) = NULL

human_mad = human_MAD_species
rownames(human_mad) = NULL

human_hmp = human_HMP_species
rownames(human_hmp) = NULL

pcoa_mat_phylum = read.csv('Taxonomic profiling/metaphlanv4/pcoa_meta_mat_phylum_normalized.csv')

all_metadata = read_csv("Taxonomic profiling/all_metadata_preformatted.csv") %>% 
  mutate(weightpc = species) %>%
  column_to_rownames("sample_id_metaphlan")

#######################################################################################################################################
## combine all data together: data transformation for PCoA and Heatmap
# animal matrix
animal_mat = animal %>%
  column_to_rownames("clade_name") %>%
  as.matrix() %>%
  t() 
# combine animal matrix with metadata
animal_meta = merge(all_metadata, animal_mat, by=0) %>%
  column_to_rownames("Row.names") # n=2422

# madagascar human matrix
human_mad_mat = human_mad %>%
  column_to_rownames("clade_name") %>%
  as.matrix() %>%
  t()
# combine madagascar human matrix with metadata
human_mad_meta = merge(all_metadata, human_mad_mat, by=0) %>% 
  column_to_rownames("Row.names") %>%
  mutate(weightpc = c("Madagascar")) # n=112

# hmp human matrix
human_hmp_mat = human_hmp %>%
  column_to_rownames("clade_name") %>%
  as.matrix() %>%
  t()
# combine madagascar human matrix with metadata
human_hmp_meta = merge(all_metadata, human_hmp_mat, by=0) %>% 
  column_to_rownames("Row.names") %>%
  mutate(weightpc = c("HMP1-II")) # n=238

# combine transformed data together
all_meta = full_join(human_mad_meta, human_hmp_meta) %>% full_join(animal_meta) # n=2772
all_meta[,12:ncol(all_meta)][is.na(all_meta[,12:ncol(all_meta)])] = 0

# save temporary matrix and metadata
pcoa_mat = all_meta[,12:ncol(all_meta)]
pcoa_meta = all_meta[,1:11]

# rename SGB to the closest known taxonomic level (function shared by Jacob Nearing)
keep_SGB <- function(bug4){
  temp <- bug4
  SGB_name <- names(bug4)
  #get suffix
  SGB_name_suffix <- gsub(".*t__", "", SGB_name)
  #get prefix
  SGB_name_prefix <- sapply(SGB_name, function(x) str_extract(x, "^(.*?)(?=(\\|g__GGB|\\|o__OFGB|\\|c__CFGB|\\|p__PFGB|\\|t__))"))
  #fix prefix to the last known assignment
  SGB_name_prefix <- gsub('.*[kpcofgst]__', "", SGB_name_prefix)
  #combined
  SGB_comb <- paste(SGB_name_prefix, SGB_name_suffix, sep = "_")
  names(bug4) <- SGB_comb
  return(bug4)
}

pcoa_mat_rename = keep_SGB(pcoa_mat)
# ordered final matrix: pcoa_mat_rename
# ordered final metadata: pcoa_meta

#######################################################################################################################################
# maaslin
# save dataframe used for heatmap
all = cbind(pcoa_meta, pcoa_mat_rename)
row.names(all) = all$sample_id
# save(all, file = paste0("Taxonomic profiling/metaphlanv4/pcoa_all.Rdata"))

cat = all[which(all$species=="cat"),]
tmp.cat = cat %>%
  select(-age, -gender, -neutered, -weight, -antibiotics, -medications, -`Internal.External`, -study_readable, -species, -weightpc) %>% 
  arrange(sample_id) %>%
  pivot_longer(!sample_id, names_to = "species", values_to = "relab") %>%
  select(species, sample_id, relab) %>%
  add_column(rep(cat$study_readable, each=3396)) 
names(tmp.cat) = c('species', 'sample_id', 'relab', 'study_readable')

dog = all[which(all$species=="dog"),]
tmp.dog = dog %>%
  select(-age, -gender, -neutered, -weight, -antibiotics, -medications, -`Internal.External`, -study_readable, -species, -weightpc) %>% 
  arrange(sample_id) %>%
  pivot_longer(!sample_id, names_to = "species", values_to = "relab") %>%
  select(species, sample_id, relab) %>%
  add_column(rep(dog$study_readable, each=3396)) 
names(tmp.dog) = c('species', 'sample_id', 'relab', 'study_readable')

human = all[which(all$species=="human"),]
tmp.human = human %>%
  select(-age, -gender, -neutered, -weight, -antibiotics, -medications, -`Internal.External`, -study_readable, -species, -weightpc) %>% 
  arrange(sample_id) %>%
  pivot_longer(!sample_id, names_to = "species", values_to = "relab") %>%
  select(species, sample_id, relab) %>%
  add_column(rep(human$study_readable, each=3396)) 
names(tmp.human) = c('species', 'sample_id', 'relab', 'study_readable')

# filter
species.list.filter <- function(df){
  n_samples = nlevels(as.factor(df$sample_id))
  df_species = df %>% 
    filter(relab > 0.00001) %>%
    group_by(species) %>%
    tally() %>%
    ungroup() %>%
    filter(n > 20) 
  dftop <- df_species$species
}

filtered_cat_list = species.list.filter(tmp.cat)
filtered_dog_list = species.list.filter(tmp.dog)
filtered_human_list = species.list.filter(tmp.human)

top_all = c(filtered_cat_list, filtered_dog_list, filtered_human_list)
prevalent_species = unique(top_all)

df_numeric = all[,11:ncol(all)]
maaslin_mat = df_numeric[ , names(df_numeric) %in% prevalent_species]

pcoa_meta_meta2 = pcoa_meta_meta %>%   
  mutate(housing = case_when(`Internal/External` == "Internal" ~ "Facility",
                             `Internal/External` == "External" ~ "Household"),
         housing = ifelse(species == "human", "Household", housing))

pcoa_meta_mat_dog = data.frame(pcoa_meta_meta2, maaslin_mat) %>% filter(species == "dog") %>% select(-c(1:12))
pcoa_meta_meta_dog = data.frame(pcoa_meta_meta2, maaslin_mat) %>% filter(species == "dog") %>% select(c(1:12))

Maaslin2(
  input_data = pcoa_meta_mat_dog, 
  input_metadata = pcoa_meta_meta_dog, 
  min_prevalence = 0,
  min_abundance = 0,
  output = "maaslin_output_housing_dog", 
  fixed_effects = c("housing"),
  random_effects = c("study_readable"),
  reference = c("housing,Facility"))

Maaslin2(
  input_data = maaslin_mat,
  input_metadata = pcoa_meta_meta2,
  min_prevalence = 0,
  min_abundance = 0,
  output = "maaslin_output_dog", 
  fixed_effects = c("species", "housing"),
  random_effects = c("study_readable"),
  reference = c("species,dog", "housing,Facility"))

Maaslin2(
  input_data = maaslin_mat,
  input_metadata = pcoa_meta_meta2,
  min_prevalence = 0,
  min_abundance = 0,
  output = "maaslin_output_cat", 
  fixed_effects = c("species", "housing"),
  random_effects = c("study_readable"),
  reference = c("species,cat", "housing,Facility"))

Maaslin2(
  input_data = maaslin_mat,
  input_metadata = pcoa_meta_meta2,
  min_prevalence = 0,
  min_abundance = 0,
  output = "maaslin_output_human", 
  fixed_effects = c("species", "housing"),
  random_effects = c("study_readable"),
  reference = c("species,human", "housing,Facility"))

#######################################################################################################################################
## PcoA
# calculate brat-curtis dissimilarity 
dist_pcoa_mat_rename = vegdist(pcoa_mat_rename) 

weights = c(case_when(pcoa_meta$species == "human" ~ 1/350,
                      pcoa_meta$species == "cat" ~ 1/367,
                      pcoa_meta$species == "dog" ~ 1/2055)) # weighted by sample size

# calculate PC1 and PC2 scores
cmd_res_pcoa_mat_rename = wcmdscale(dist_pcoa_mat_rename, 
                                    k = 2,
                                    eig = TRUE,
                                    w = weights)
# explained variation percent
percent_explained = 100 * cmd_res_pcoa_mat_rename$eig / sum(cmd_res_pcoa_mat_rename$eig)
PC1 = percent_explained[1] %>% round(digits = 2) # 13.33
PC2 = percent_explained[2] %>% round(digits = 2) # 9.47

# select first two PC
pcoa_mat_2PC = tibble(PC1 = cmd_res_pcoa_mat_rename$points[,1], 
                      PC2 = cmd_res_pcoa_mat_rename$points[,2])

# calculate weighted average scores of bugs driving the cluster of PCoA
wascores = data.frame(wascores(pcoa_mat_2PC, pcoa_mat_rename))
rownames(wascores) = gsub("_", " ", rownames(wascores), fixed=TRUE)

# prepare two inputs for PcoA 
data_wa_sub = wascores[c('Enterobacteriaceae SGB1818',
                         'Actinobacteria SGB14350', 
                         'Phocaeicola vulgatus SGB1814',
                         'Prevotella copri clade A SGB1626', 
                         'Bifidobacterium adolescentis SGB17244 group'),] # selected by relative abundance clustering

pcoa_df = data.frame(pcoa_mat_2PC, pcoa_meta)

# color setting
species.colors = c(cat = "indianred", dog = "#E69F00", `HMP1-II` = "#56B4E0", Madagascar = "#0f3b50")

# main PCoA
cairo_pdf("Taxonomic profiling/PDFforTobyn/figure3/weighted_pcoa_2xhuman_species_v4.pdf", width=10, height=7, fallback_resolution = 300)

ggplot(data = pcoa_df %>% arrange(species)) + 
  geom_point(size = 3, shape = 21, aes(x = PC1, y = PC2, fill = weightpc), alpha = 0.7) + 
  geom_shadowtext(data = data_wa_sub, aes(x = PC1, y = PC2, label = rownames(data_wa_sub)), 
                  check_overlap = TRUE, vjust = 0, hjust = 0.5, size = 5, 
                  fontface = "italic", color = "black", bg.color = "white") +
  theme_classic() + 
  theme(legend.text = element_text(size = 16), 
        legend.title = element_text(size = 16, face = "bold"), 
        legend.position = "left",
        axis.text = element_text(size = 12), 
        axis.title = element_text(size = 16, face = "bold")) +
  scale_color_manual(values = species.colors) + 
  scale_fill_manual(values = species.colors) + 
  labs(title = NULL, x = paste0("PCoA1 [", PC1,"%]"), y = paste0("PCoA2 [",PC2,"%]"), fill = "Host Species")

dev.off()

# Bacteroidetes PcoA
pcoa_df_bac = data.frame(pcoa_df, Bacteroidetes = pcoa_mat_phylum$Bacteroidetes)

cairo_pdf("Taxonomic profiling/PDFforTobyn/figure3/weighted_pcoa_2xhuman_species_Bacteroidetes_v4.pdf", width=10, height=7, fallback_resolution = 300)

ggplot(data = pcoa_df_bac %>% arrange(species)) + 
  geom_point(size = 3, shape = 21, aes(x = PC1, y = PC2, fill = Bacteroidetes), alpha = 0.7) + 
  theme_classic() + 
  theme(legend.text = element_text(size = 16), 
        legend.title = element_text(size = 16, face = "bold"), 
        legend.position = "left",
        axis.text = element_text(size = 12), 
        axis.title = element_text(size = 16, face = "bold")) +
  scale_fill_gradient(low = "white", high = "#008080", limits =  c(0,1)) + 
  labs(title = NULL, x=paste0("PCoA1 [", PC1,"%]"), y = paste0("PCoA2 [",PC2,"%]"), fill = "Bacteroidetes \nRelative Abundance")

dev.off()

# Actinobacteria PcoA
pcoa_df_Act = data.frame(pcoa_df, Actinobacteria = pcoa_mat_phylum$Actinobacteria)

cairo_pdf("Taxonomic profiling/PDFforTobyn/figure3/weighted_pcoa_2xhuman_species_Actinobacteria_v4.pdf", width=10, height=7, fallback_resolution = 300)

ggplot(data = pcoa_df_Act %>% arrange(species)) + 
  geom_point(size = 3, shape = 21, aes(x = PC1, y = PC2, fill = Actinobacteria), alpha = 0.7) + 
  theme_classic() + 
  theme(legend.text = element_text(size = 16), 
        legend.title = element_text(size = 16, face = "bold"), 
        legend.position = "left",
        axis.text = element_text(size = 12), 
        axis.title = element_text(size = 16, face = "bold")) +
  scale_fill_gradient(low = "white", high = "#FF69B4", limits =  c(0,1)) + 
  labs(title = NULL, x=paste0("PCoA1 [", PC1,"%]"), y = paste0("PCoA2 [",PC2,"%]"), fill = "Actinobacteria \nRelative Abundance")

dev.off()

#######################################################################################################################################
## heatmap
# filter criteria: > 10^5 in at least 25% or 10% of samples within the host species in at least 2 studies
species.list.filter = function(df){
  n_samples = nlevels(as.factor(df$sample_id))
  df_species = df %>% 
    filter(relab > 0.00001) %>%
    group_by(species) %>%
    tally() %>%
    ungroup() %>%
    filter(n > 0.25 * n_samples) 
  dftop = df_species$species
}

species.list.filter.abundant = function(df){
  n_samples = nlevels(as.factor(df$sample_id))
  df_species = df %>% 
    filter(relab > 0.00001) %>%
    group_by(species) %>%
    tally() %>%
    ungroup() %>%
    filter(n > 0.1 * n_samples) 
  dftop = df_species$species
}

find.2studies = function(list){
  top_all = unlist(list)
  prevalent_species = top_all[duplicated(top_all)]
  top = unique(prevalent_species)
}

# cat top 10 list
cat = all[which(all$species=="cat"),]

tmp.cat = cat %>%
  select(-age, -gender, -weight, -antibiotics, -medications, -`Facility/Household`, -`Private/Public`, -study_readable, -species, -weightpc) %>% 
  arrange(sample_id) %>%
  pivot_longer(!sample_id, names_to = "species", values_to = "relab") %>%
  select(species, sample_id, relab) %>%
  add_column(rep(cat$study_readable, each=3396)) 
names(tmp.cat) = c('species', 'sample_id', 'relab', 'study_readable')

# apply for each study
cattop_25 = list()
cattop_10 = list()

for (i in unique(tmp.cat$study_readable)) {
  cat_i = tmp.cat[tmp.cat$study_readable == i,]
  
  cattop_25[[i]] = species.list.filter(cat_i)
  cattop_10[[i]] = species.list.filter.abundant(cat_i)
}

cattop.25 = find.2studies(cattop_25)
cattop.10 = find.2studies(cattop_10)

cat_numeric = cat[,12:ncol(cat)]
top_cat = cat_numeric[,names(cat_numeric) %in% unique(c(cattop.25, cattop.10))]

cattop_ori = names(sort(colSums(top_cat), decreasing = TRUE))[1:10] # find top 10 
cattop_ori = names(sort(colSums(top_cat), decreasing = TRUE))[1:8] # find top 8

# dog top 10 list
dog = all[which(all$species=="dog"),]

tmp.dog = dog %>%
  select(-age, -gender, -weight, -antibiotics, -medications, -`Facility/Household`, -`Private/Public`, -study_readable, -species, -weightpc) %>% 
  arrange(sample_id) %>%
  pivot_longer(!sample_id, names_to = "species", values_to = "relab") %>%
  select(species, sample_id, relab) %>%
  add_column(rep(dog$study_readable, each=3396)) 
names(tmp.dog) = c('species', 'sample_id', 'relab', 'study_readable')

# apply for each study
dogtop_25 = list()
dogtop_10 = list()

for (i in unique(tmp.dog$study_readable)) {
  dog_i = tmp.dog[tmp.dog$study_readable == i,]
  
  dogtop_25[[i]] = species.list.filter(dog_i)
  dogtop_10[[i]] = species.list.filter.abundant(dog_i)
}

dogtop.25 = find.2studies(dogtop_25)
dogtop.10 = find.2studies(dogtop_10)

dog_numeric = dog[,12:ncol(dog)]
top_dog = dog_numeric[,names(dog_numeric) %in% unique(c(dogtop.25, dogtop.10))] # dogtop.25 is the same as dogtop.10

dogtop_ori = names(sort(colSums(top_dog), decreasing = TRUE))[1:10] # find top 10 
dogtop_ori = names(sort(colSums(top_dog), decreasing = TRUE))[1:8] # find top 8

# human top 10 list
human = all[which(all$species=="human"),]

tmp.human <- human %>%
  select(-age, -gender, -weight, -antibiotics, -medications, -`Facility/Household`, -`Private/Public`, -study_readable, -species, -weightpc) %>% 
  arrange(sample_id) %>%
  pivot_longer(!sample_id, names_to = "species", values_to = "relab") %>%
  select(species, sample_id, relab) %>%
  add_column(rep(human$study_readable, each=3396)) 
names(tmp.human) = c('species', 'sample_id', 'relab', 'study_readable')

# apply for each study
humantop_25 = list()
humantop_10 = list()

for (i in unique(tmp.human$study_readable)) {
  human_i = tmp.human[tmp.human$study_readable == i,]
  
  humantop_25[[i]] = species.list.filter(human_i)
  humantop_10[[i]] = species.list.filter.abundant(human_i)
}

humantop.25 = find.2studies(humantop_25)
humantop.10 = find.2studies(humantop_10)

human_numeric = human[,12:ncol(human)]
top_human = human_numeric[,names(human_numeric) %in% unique(c(humantop.25, humantop.10))] # not the same

humantop_ori = names(sort(colSums(top_human), decreasing = TRUE))[1:10] # find top 10 
humantop_ori = names(sort(colSums(top_human), decreasing = TRUE))[1:8] # find top 8

# final lists across host
topspecies = c(cattop_ori, dogtop_ori, humantop_ori) %>% unique() # 27 (top 10) or 21 (top 8)
# save(topspecies, file = paste0("Taxonomic profiling/metaphlanv4/top27_list_heatmap.Rdata"))

# sort out columns based on final lists 
df_numeric = all[,12:ncol(all)]
top = df_numeric[, names(df_numeric) %in% topspecies]

# transpose for heatmap
top_t = t(top) 
rownames(top_t) = gsub("_", " ", rownames(top_t), fixed=TRUE)
min_relab = min(top_t[top_t>0]) / 10 # set 0 to be 1/10 of the minimum relative abundance = 2.000001e-08
logtop_t = top_t # save for log10 transformation
logtop_t[logtop_t == 0] = min_relab # matrix

metadata = pcoa_meta %>%
  select(`Study ID` = "study_readable", `Host Species` = "species", "Facility/Household", "Private/Public")
metadata[is.na(metadata)] = "NA" # metadata (also column annotation)

uSGB.meta = data.frame("old_bug_id" = rownames(top_t)) %>%
  mutate(SGB = case_when(grepl("SGB14350", `old_bug_id`) ~ "uSGB",
                         grepl("SGB53888", `old_bug_id`) ~ "uSGB",
                         grepl("SGB15313", `old_bug_id`) ~ "uSGB",
                         grepl("SGB1818", `old_bug_id`) ~ "uSGB",
                         grepl("SGB1481", `old_bug_id`) ~ "uSGB",
                         TRUE ~ "kSGB")) %>%
  column_to_rownames('old_bug_id') # row annotation

# plot heatmap
ann_colors = list(
  `Study ID` = c(`Madagascar` = "#0f3b50", `HMP1-II` = "#56B4E0", `Cross-sectional Study2` = "#b7aaba", `Cross-sectional Study3` = "#d44ab4", `Deusch et al. (2014)` = "#639CCF",
                 `Allaway et al.` = "#31378c", `Deusch et al. (2015)` = "#6d81ae", `DietInt Study4` = "#798C7E", `DietInt Study5` = "#b05c63",
                 `Cross-sectional Study1` = "#FFFFB3", `DietInt Study1` = "#d69d68", `DietInt Study3` = "#7eda86", `DietInt Study2` = "#fbc086",
                 `Young et al.` = "#74d0d1", `Ateba et al.` = "#e0a8f5", `Liu et al.` = "#d2bed7", `Tanprasertsuk et al.` = "#c7a679",
                 `Ma et al.` = "#612141", `Xu et al.` = "#ae4109", `Alessandri et al.` = "#b435ee", `Wang et al.` = "#e9fdc3",
                 `Maldonado-Contreras et al.` = "#c7f4fc"),
  `Host Species` = c(dog = "#E69F00", cat = "indianred", human = "#56B4E0"),
  `Facility/Household` = c(Facility = "#F2C143", `Household` = "#3A8A62", "NA" = "gray"),
  `Private/Public` = c(`Private` = "#A07855" , `Public` = "#D4B996", "NA" = "gray"),
  SGB = c(uSGB = "#FF0000", kSGB = "#000000"))

cairo_pdf("Taxonomic profiling/PDFforTobyn/figure3/heatmap_filtered_top27_2Xhuman_v4_naturalcluster.pdf", width=20, height=9, fallback_resolution = 300)
cairo_pdf("Taxonomic profiling/PDFforTobyn/figure3/heatmap_filtered_top21_2Xhuman_v4_naturalcluster.pdf", width=20, height=9, fallback_resolution = 300)

pheatmap(mat = log10(logtop_t), 
         show_colnames = FALSE,
         color = inferno(10),
         border_color = NA, 
         annotation_col = metadata,
         annotation_row = uSGB.meta,
         annotation_colors = ann_colors,
         cellheight = 18, 
         cellwidth = 0.3,
         fontsize = 12,
         legend = TRUE,
         name = "log10 Scale Relative Abundance",
         annotation_names_row = FALSE)

dev.off()

#######################################################################################################################################
## density plots
# prepare dataframe
df_in = all[-c(1:10)] # see "all" dataframe from Figure3_PcoA&Heatmap
colnames(df_in) = gsub("_", " ", colnames(df_in), fixed=TRUE) # matrix

metadata_in = all[c(1,3)]
names(metadata_in) = c("sample_id", "Host Species") # metadata

# bugs among the interest
interest = c("Phocaeicola vulgatus SGB1814", "Collinsella intestinalis SGB14741", 
             "Oscillospiraceae SGB15313", "Succinivibrionaceae SGB3677",
             "Bifidobacterium pseudolongum SGB17279", "Megasphaera elsdenii SGB5862", 
             "Actinobacteria SGB14350", "Firmicutes SGB5749", 
             "Helicobacter canis SGB21969", "Prevotella copri clade C SGB1644",
             "Enterococcaceae SGB6260")

df = cbind(metadata_in, df_in %>% select(matches(interest))) # combine

# filter criteria: > 10^5 in at least 3 samples of the given host species
human_df = df %>% filter(`Host Species` == "human")
for (i in 3:ncol(human_df)) {
  if (sum(human_df[[i]] > 0.00001) >= 3) {
    human_df[[i]][human_df[[i]] < 0.00001] <- NA
  } else {
    human_df[[i]] <- NA
  }
}

cat_df = df %>% filter(`Host Species` == "cat")
for (i in 3:ncol(cat_df)) {
  if (sum(cat_df[[i]] > 0.00001) >= 3) {
    cat_df[[i]][cat_df[[i]] < 0.00001] <- NA
  } else {
    cat_df[[i]] <- NA
  }
}

dog_df = df %>% filter(`Host Species` == "dog")
for (i in 3:ncol(dog_df)) {
  if (sum(dog_df[[i]] > 0.00001) >= 3) {
    dog_df[[i]][dog_df[[i]] < 0.00001] <- NA
  } else {
    dog_df[[i]] <- NA
  }
}

df = rbind(human_df, cat_df, dog_df) # final input

# plotting function: plot_rel - with axis value, plot_rel2 - no x axis value
plot_rel = function(df, bug){
  df_bug = cbind(df[c(1:2)], relab = df[bug]) %>% add_column(bug = names(df[bug]))
  names(df_bug) = c("Study ID", "Host Species", "relab", "bug")
  df_bug$relab = log10(df_bug$relab)
  
  species.colors = c(cat = "indianred", dog = "#E69F00", human = "#56B4E0")
  
  density_plot = ggplot(df_bug, aes(x = relab, fill = `Host Species`)) + 
    geom_density(aes(y=after_stat(density)), alpha = 0.9, show.legend = FALSE) +
    geom_text(aes(label = bug), size = 13, x = -5, y = 1, hjust = 0, vjust = 1, check_overlap = TRUE, fontface = "italic") +
    labs(title=NULL, x="log10 scale Relative abundance", y="Density", fill = NULL) +
    theme_bw() +
    theme(axis.text=element_text(size= 30),
          legend.title=element_text(size = 30, face = "bold"), 
          legend.text= element_text(size = 30),
          axis.title = element_text(size = 35, face = "bold", color = "white")) +
    scale_fill_manual(values = species.colors) +
    xlim(-5, 1) +
    ylim(0, 1)
  
  missing_df_dog = cbind(df[c(1:2)], relab = df[bug]) %>% filter(`Host Species` == "dog")
  missing_df_dog[-c(1:2)] = ifelse(is.na(missing_df_dog[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_dog[3])
  proportion = (colSums(missing_df_dog[3])/nrow(missing_df_dog[3]))*100
  host = c("dog")
  
  dog = data.frame(species, proportion, host)
  
  missing_df_cat = cbind(df[c(1:2)], relab = df[bug]) %>% filter(`Host Species` == "cat")
  missing_df_cat[-c(1:2)] = ifelse(is.na(missing_df_cat[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_cat[3])
  proportion =  (colSums(missing_df_cat[3])/nrow(missing_df_cat[3]))*100
  host = c("cat")
  
  cat = data.frame(species, proportion, host)
  
  missing_df_human = cbind(df[c(1:2)], relab = df[bug]) %>% filter(`Host Species` == "human")
  missing_df_human[-c(1:2)] = ifelse(is.na(missing_df_human[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_human[3])
  proportion =  (colSums(missing_df_human[3])/nrow(missing_df_human[3]))*100
  host = c("human")
  
  human = data.frame(species, proportion, host)
  
  missing_df_p = rbind(cat, dog, human)
  
  missing_barplot= ggplot(missing_df_p, aes(x = host, y = proportion, fill = host)) +
    geom_bar(stat="identity") +
    theme_bw() +
    theme(
      axis.text.x = element_text(size = 30, color = "white"),
      axis.text.y = element_text(size = 30),
      axis.ticks.x = element_blank(),
      axis.title.y = element_text(size = 35, face = "bold", color = "white"),
      axis.title.x = element_text(size = 35, face = "bold", color = "white")) +
    scale_fill_manual(values = species.colors) +
    ylim(0, 100) +
    labs(y = "Proportion (%) of missing value", fill = NULL, x = "Host Species", title = NULL) + 
    guides(fill ="none")
  
  grid.arrange(missing_barplot, density_plot, ncol = 2, widths = c(0.5, 2))}

plot_rel2 = function(df, bug){
  df_bug = cbind(df[c(1:2)], relab = df[bug]) %>% add_column(bug = names(df[bug]))
  names(df_bug) = c("Study ID", "Host Species", "relab", "bug")
  df_bug$relab = log10(df_bug$relab)
  
  species.colors = c(cat = "indianred", dog = "#E69F00", human = "#56B4E0")
  
  density_plot = ggplot(df_bug, aes(x = relab, fill = `Host Species`)) + 
    geom_density(aes(y=after_stat(density)), alpha = 0.9, show.legend = FALSE) +
    geom_text(aes(label = bug), size = 13, x = -5, y = 1, hjust = 0, vjust = 1, check_overlap = TRUE, fontface = "italic") +
    labs(title=NULL, x="log10 scale Relative abundance", y="Density", fill = NULL) +
    theme_bw() +
    theme(axis.text.y =element_text(size= 30),
          axis.text.x =element_text(size= 30, color = "white"),
          axis.ticks.x = element_blank(),
          legend.title=element_text(size = 30, face = "bold"), 
          legend.text= element_text(size = 30),
          axis.title = element_text(size = 35, face = "bold", color = "white")) +
    scale_fill_manual(values = species.colors) +
    xlim(-5, 1) +
    ylim(0, 1)
  
  missing_df_dog = cbind(df[c(1:2)], relab = df[bug]) %>% filter(`Host Species` == "dog")
  missing_df_dog[-c(1:2)] = ifelse(is.na(missing_df_dog[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_dog[3])
  proportion = (colSums(missing_df_dog[3])/nrow(missing_df_dog[3]))*100
  host = c("dog")
  
  dog = data.frame(species, proportion, host)
  
  missing_df_cat = cbind(df[c(1:2)], relab = df[bug]) %>% filter(`Host Species` == "cat")
  missing_df_cat[-c(1:2)] = ifelse(is.na(missing_df_cat[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_cat[3])
  proportion =  (colSums(missing_df_cat[3])/nrow(missing_df_cat[3]))*100
  host = c("cat")
  
  cat = data.frame(species, proportion, host)
  
  missing_df_human = cbind(df[c(1:2)], relab = df[bug]) %>% filter(`Host Species` == "human")
  missing_df_human[-c(1:2)] = ifelse(is.na(missing_df_human[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_human[3])
  proportion =  (colSums(missing_df_human[3])/nrow(missing_df_human[3]))*100
  host = c("human")
  
  human = data.frame(species, proportion, host)
  
  missing_df_p = rbind(cat, dog, human)
  
  missing_barplot= ggplot(missing_df_p, aes(x = host, y = proportion, fill = host)) +
    geom_bar(stat="identity") +
    theme_bw() +
    theme(
      axis.text.x = element_text(size = 30, color = "white"),
      axis.text.y = element_text(size = 30),
      axis.ticks.x = element_blank(),
      axis.title.y = element_text(size = 35, face = "bold", color = "white"),
      axis.title.x = element_text(size = 35, face = "bold", color = "white")) +
    scale_fill_manual(values = species.colors) +
    ylim(0, 100) +
    labs(y = "Proportion (%) of missing value", fill = NULL, x = "Host Species", title = NULL) + 
    guides(fill ="none")
  
  grid.arrange(missing_barplot, density_plot, ncol = 2, widths = c(0.5, 2))}

# get legend
df_bug = cbind(df[c(1:2)], relab = df['Firmicutes SGB5749']) %>% add_column(bug = names(df['Firmicutes SGB5749']))
names(df_bug) = c("Study ID", "Host Species", "relab", "bug")
df_bug$relab = log10(df_bug$relab)

species.colors = c(cat = "indianred", dog = "#E69F00", human = "#56B4E0")

density_plot = ggplot(df_bug, aes(x = relab, fill = `Host Species`)) + 
  geom_density(aes(y=after_stat(density)), alpha = 0.9) +
  geom_text(aes(label = bug), size = 15, x = -5, y = 1, hjust = 0, vjust = 1, check_overlap = TRUE, fontface = "italic") +
  labs(title=NULL, x="log10 scale Relative abundance", y="Density", fill = "Host Species") +
  theme_bw() +
  theme(axis.text=element_text(size= 30),
        legend.title=element_text(size = 50, face = "bold"), 
        legend.text= element_text(size = 50),
        axis.title = element_text(size = 35, face = "bold", color = "white")) +
  scale_fill_manual(values = species.colors) +
  xlim(-5, 1) +
  ylim(0, 1)


legend = get_legend(density_plot)

# make each plot for each bug
p1 = plot_rel2(df, bug = 'Phocaeicola vulgatus SGB1814')
p2 = plot_rel2(df, bug = 'Bifidobacterium pseudolongum SGB17279')
p3 = plot_rel2(df, bug = 'Helicobacter canis SGB21969')
p4 = plot_rel2(df, bug = 'Collinsella intestinalis SGB14741')
p5 = plot_rel2(df, bug = 'Megasphaera elsdenii SGB5862')
p6 = plot_rel2(df, bug = 'Prevotella copri clade C SGB1644')
p7 = plot_rel2(df, bug = 'Oscillospiraceae SGB15313')
p8 = plot_rel2(df, bug = 'Actinobacteria SGB14350')
p9 = plot_rel(df, bug = 'Enterococcaceae SGB6260')
p10 = plot_rel(df, bug = 'Succinivibrionaceae SGB3677')
p11 = plot_rel(df, bug = 'Firmicutes SGB5749')

# axis title
bottom = textGrob("log10 Scale Relative Abundance", gp = gpar(fontsize = 60, fontface = "bold"))
yleft = textGrob("Proportion (%) of Missing Values", rot = 90, gp = gpar(fontsize = 60, fontface = "bold"))

# annotation
title1 = grobTree(rectGrob(height = 0.7, width = 0.9, gp=gpar(fill="gray")), 
                  textGrob("Shared SGBs", gp=gpar(fontsize=50, fontface="bold")))
title2 = grobTree(rectGrob(height = 0.7, width = 0.9, gp=gpar(fill="gray")),
                  textGrob("Companion Animals Only", gp=gpar(fontsize=50, fontface="bold")))
title3 = grobTree(rectGrob(height = 0.7, width = 0.9, gp=gpar(fill="gray")),
                  textGrob("SGBs Unique to Host Species", gp=gpar(fontsize=50, fontface="bold")))
title4 = grobTree(rectGrob(height = 0.7, width = 0.9, gp=gpar(fill="gray")), 
                  textGrob("kSBGs", rot = 90, gp=gpar(fontsize=50, fontface="bold")))
title5 = grobTree(rectGrob(height = 0.7, width = 0.9, gp=gpar(fill="gray")), 
                  textGrob("uSBGs", rot = 90, gp=gpar(fontsize=50, fontface="bold")))

# combine all figures
cairo_pdf("Taxonomic profiling/PDFforTobyn/figure3/density_full.pdf", width=55, height=35, fallback_resolution = 300)

main = grid.arrange(arrangeGrob(title4, title5, ncol = 1),
                    arrangeGrob(title1, title2, title3,
                                p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, legend,
                                ncol = 3,
                                bottom = bottom,
                                left = yleft, heights = c(0.3, 1, 1, 1, 1)), ncol = 2, widths=c(0.03, 1))
dev.off()

# density supplement
metadata_in = all[c(1,3)]
names(metadata_in) = c("sample_id", "Host Species")

df_numeric = all[,12:ncol(all)]
colnames(df_numeric) = gsub("_", " ", colnames(df_numeric), fixed=TRUE) # matrix

topspecies = gsub("_", " ", topspecies, fixed=TRUE)
all_species = unique(c(topspecies, interest))

top = df_numeric[, names(df_numeric) %in% all_species]

df = cbind(metadata_in, top)

human_df = df %>% filter(`Host Species` == "human")
for (i in 3:ncol(human_df)) {
  if (sum(human_df[[i]] > 0.00001) >= 3) {
    human_df[[i]][human_df[[i]] < 0.00001] <- NA
  } else {
    human_df[[i]] <- NA
  }
}

cat_df = df %>% filter(`Host Species` == "cat")
for (i in 3:ncol(cat_df)) {
  if (sum(cat_df[[i]] > 0.00001) >= 3) {
    cat_df[[i]][cat_df[[i]] < 0.00001] <- NA
  } else {
    cat_df[[i]] <- NA
  }
}

dog_df = df %>% filter(`Host Species` == "dog")
for (i in 3:ncol(dog_df)) {
  if (sum(dog_df[[i]] > 0.00001) >= 3) {
    dog_df[[i]][dog_df[[i]] < 0.00001] <- NA
  } else {
    dog_df[[i]] <- NA
  }
}

df = rbind(human_df, cat_df, dog_df)

df_set1 = df %>% 
  select(c(1:2, 3:10)) %>%
  pivot_longer(!c(1:2), names_to = "species", values_to = "relab")

df_set2 = df %>% 
  select(c(1:2, 11:18)) %>%
  pivot_longer(!c(1:2), names_to = "species", values_to = "relab")

df_set3 = df %>% 
  select(c(1:2, 19:26)) %>%
  pivot_longer(!c(1:2), names_to = "species", values_to = "relab")

df_set4 = df %>% 
  select(c(1:2, 27:34)) %>%
  pivot_longer(!c(1:2), names_to = "species", values_to = "relab")

# log10scale set1
species.colors = c(cat = "indianred", dog = "#E69F00", human = "#56B4E0")

df_set1$relab = log10(df_set1$relab)
df_set1$species <- factor(df_set1$species, levels = unique(df_set1$species))

density_plot1 = ggplot(df_set1, aes(x = relab, fill = `Host Species`)) + 
  geom_density(aes(y=after_stat(density)), alpha = 0.9, show.legend = FALSE) +
  geom_text(aes(label = species), size = 10, x = -5, y = 1.5, hjust = 0, vjust = 0.5, check_overlap = TRUE, fontface = "italic") +
  labs(title=NULL, x="log10 scale Relative abundance", y=NULL, fill = "Host Species") +
  theme_bw() +
  theme(axis.text=element_text(size= 30),
        legend.title=element_text(size = 30, face = "bold"), 
        legend.text= element_text(size = 30),
        axis.title = element_text(size = 35, face = "bold", color = "white"),
        strip.text = element_blank(),
        strip.background = element_blank()) +
  scale_fill_manual(values = species.colors) +
  xlim(-5, 1) + 
  ylim(0, 1.6) + 
  facet_wrap(~ species, scale = "free_y", ncol= 1, strip.position="right")

# missing heatmap
{
  missing_df_dog =  df %>% 
    select(c(1:2, 3:10)) %>% 
    filter(`Host Species` == "dog")
  missing_df_dog[-c(1:2)] = ifelse(is.na(missing_df_dog[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_dog[3:10])
  proportion =  (colSums(missing_df_dog[3:10])/nrow(missing_df_dog[3:10]))*100
  host = c("dog")
  
  dog = data.frame(species, proportion, host)
  
  missing_df_cat = df %>% 
    select(c(1:2, 3:10)) %>% 
    filter(`Host Species` == "cat")
  missing_df_cat[-c(1:2)] = ifelse(is.na(missing_df_cat[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_cat[3:10])
  proportion =  (colSums(missing_df_cat[3:10])/nrow(missing_df_cat[3:10]))*100
  host = c("cat")
  
  cat = data.frame(species, proportion, host)
  
  missing_df_human = df %>% 
    select(c(1:2, 3:10)) %>% 
    filter(`Host Species` == "human")
  missing_df_human[-c(1:2)] = ifelse(is.na(missing_df_human[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_human[3:10])
  proportion =  (colSums(missing_df_human[3:10])/nrow(missing_df_human[3:10]))*100
  host = c("human")
  
  human = data.frame(species, proportion, host)
  
  missing_df_p = rbind(cat, dog, human)
  missing_df_p$species <- factor(missing_df_p$species, levels = unique(df_set1$species))
  
  missing_barplot1 = ggplot(missing_df_p, aes(x = host, y = proportion, fill = host)) +
    geom_bar(stat="identity") +
    theme_bw() +
    theme(
      axis.text.x = element_text(size = 30, color = "white"),
      axis.text.y = element_text(size = 30),
      axis.ticks.x = element_blank(),
      axis.title.y = element_text(size = 35, face = "bold", color = "white"),
      axis.title.x = element_text(size = 35, face = "bold", color = "white"),
      strip.text = element_blank(),
      strip.background = element_blank()) +
    scale_fill_manual(values = species.colors) +
    ylim(0, 100) +
    labs(y = "Proportion (%) of missing value", fill = NULL, x = "Host Species", title = NULL) +
    facet_wrap(~ species, ncol= 1, strip.position="right") +
    guides(fill ="none")
  }

plot1 = grid.arrange(missing_barplot1, density_plot1, ncol = 2, widths = c(0.5, 1.5))

# log10scale
df_set2$relab = log10(df_set2$relab)
df_set2$species <- factor(df_set2$species, levels = unique(df_set2$species))

density_plot2 = ggplot(df_set2, aes(x = relab, fill = `Host Species`)) + 
  geom_density(aes(y=after_stat(density)), alpha = 0.9, show.legend = FALSE) +
  geom_text(aes(label = species), size = 10, x = -5, y = 1.5, hjust = 0, vjust = 0.5, check_overlap = TRUE, fontface = "italic") +
  labs(title=NULL, x="log10 scale Relative abundance", y=NULL, fill = "Host Species") +
  theme_bw() +
  theme(axis.text=element_text(size= 30),
        legend.title=element_text(size = 30, face = "bold"), 
        legend.text= element_text(size = 30),
        axis.title = element_text(size = 35, face = "bold", color = "white"),
        strip.text = element_blank(),
        strip.background = element_blank()) +
  scale_fill_manual(values = species.colors) +
  xlim(-5, 1) + 
  ylim(0, 1.6) + 
  facet_wrap(~ species, scale = "free_y", ncol= 1, strip.position="right")

# missing heatmap
{
  missing_df_dog = df %>% 
    select(c(1:2, 11:18)) %>% 
    filter(`Host Species` == "dog")
  missing_df_dog[-c(1:2)] = ifelse(is.na(missing_df_dog[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_dog[3:10])
  proportion =  (colSums(missing_df_dog[3:10])/nrow(missing_df_dog[3:10]))*100
  host = c("dog")
  
  dog = data.frame(species, proportion, host)
  
  missing_df_cat = df %>% 
    select(c(1:2, 11:18)) %>% 
    filter(`Host Species` == "cat")
  missing_df_cat[-c(1:2)] = ifelse(is.na(missing_df_cat[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_cat[3:10])
  proportion =  (colSums(missing_df_cat[3:10])/nrow(missing_df_cat[3:10]))*100
  host = c("cat")
  
  cat = data.frame(species, proportion, host)
  
  missing_df_human = df %>% 
    select(c(1:2, 11:18)) %>% 
    filter(`Host Species` == "human")
  missing_df_human[-c(1:2)] = ifelse(is.na(missing_df_human[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_human[3:10])
  proportion =  (colSums(missing_df_human[3:10])/nrow(missing_df_human[3:10]))*100
  host = c("human")
  
  human = data.frame(species, proportion, host)
  
  missing_df_p = rbind(cat, dog, human)
  missing_df_p$species <- factor(missing_df_p$species, levels = unique(df_set2$species))
  
  missing_barplot2 = ggplot(missing_df_p, aes(x = host, y = proportion, fill = host)) +
    geom_bar(stat="identity") +
    theme_bw() +
    theme(
      axis.text.x = element_text(size = 30, color = "white"),
      axis.text.y = element_text(size = 30),
      axis.ticks.x = element_blank(),
      axis.title.y = element_text(size = 35, face = "bold", color = "white"),
      axis.title.x = element_text(size = 35, face = "bold", color = "white"),
      strip.text = element_blank(),
      strip.background = element_blank()) +
    scale_fill_manual(values = species.colors) +
    ylim(0, 100) +
    labs(y = "Proportion (%) of missing value", fill = NULL, x = "Host Species", title = NULL) +
    facet_wrap(~ species, ncol= 1, strip.position="right") +
    guides(fill ="none")
  }

plot2 = grid.arrange(missing_barplot2, density_plot2, ncol = 2, widths = c(0.5, 1.5))

# log10scale
df_set3$relab = log10(df_set3$relab)
df_set3$species <- factor(df_set3$species, levels = unique(df_set3$species))

density_plot3 = ggplot(df_set3, aes(x = relab, fill = `Host Species`)) + 
  geom_density(aes(y=after_stat(density)), alpha = 0.9, show.legend = FALSE) +
  geom_text(aes(label = species), size = 10, x = -5, y = 1.5, hjust = 0, vjust = 0.5, check_overlap = TRUE, fontface = "italic") +
  labs(title=NULL, x="log10 scale Relative abundance", y=NULL, fill = "Host Species") +
  theme_bw() +
  theme(axis.text=element_text(size= 30),
        legend.title=element_text(size = 30, face = "bold"), 
        legend.text= element_text(size = 30),
        axis.title = element_text(size = 35, face = "bold", color = "white"),
        strip.text = element_blank(),
        strip.background = element_blank()) +
  scale_fill_manual(values = species.colors) +
  xlim(-5, 1) + 
  ylim(0, 1.6) + 
  facet_wrap(~ species, scale = "free_y", ncol= 1, strip.position="right")

# missing heatmap
{
  missing_df_dog = df %>% 
    select(c(1:2, 19:26)) %>% 
    filter(`Host Species` == "dog")
  missing_df_dog[-c(1:2)] = ifelse(is.na(missing_df_dog[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_dog[3:10])
  proportion =  (colSums(missing_df_dog[3:10])/nrow(missing_df_dog[3:10]))*100
  host = c("dog")
  
  dog = data.frame(species, proportion, host)
  
  missing_df_cat = df %>% 
    select(c(1:2, 19:26)) %>% 
    filter(`Host Species` == "cat")
  missing_df_cat[-c(1:2)] = ifelse(is.na(missing_df_cat[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_cat[3:10])
  proportion =  (colSums(missing_df_cat[3:10])/nrow(missing_df_cat[3:10]))*100
  host = c("cat")
  
  cat = data.frame(species, proportion, host)
  
  missing_df_human = df %>% 
    select(c(1:2, 19:26)) %>% 
    filter(`Host Species` == "human")
  missing_df_human[-c(1:2)] = ifelse(is.na(missing_df_human[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_human[3:10])
  proportion =  (colSums(missing_df_human[3:10])/nrow(missing_df_human[3:10]))*100
  host = c("human")
  
  human = data.frame(species, proportion, host)
  
  missing_df_p = rbind(cat, dog, human)
  missing_df_p$species <- factor(missing_df_p$species, levels = unique(df_set3$species))
  
  missing_barplot3 = ggplot(missing_df_p, aes(x = host, y = proportion, fill = host)) +
    geom_bar(stat="identity") +
    theme_bw() +
    theme(
      axis.text.x = element_text(size = 30, color = "white"),
      axis.text.y = element_text(size = 30),
      axis.ticks.x = element_blank(),
      axis.title.y = element_text(size = 35, face = "bold", color = "white"),
      axis.title.x = element_text(size = 35, face = "bold", color = "white"),
      strip.text = element_blank(),
      strip.background = element_blank()) +
    scale_fill_manual(values = species.colors) +
    ylim(0, 100) +
    labs(y = "Proportion (%) of missing value", fill = NULL, x = "Host Species", title = NULL) +
    facet_wrap(~ species, ncol= 1, strip.position="right") +
    guides(fill ="none")
  }

plot3 = grid.arrange(missing_barplot3, density_plot3, ncol = 2, widths = c(0.5, 1.5))

# log10scale
df_set4$relab = log10(df_set4$relab)
df_set4$species <- factor(df_set4$species, levels = unique(df_set4$species))

density_plot4 = ggplot(df_set4, aes(x = relab, fill = `Host Species`)) + 
  geom_density(aes(y=after_stat(density)), alpha = 0.9, show.legend = FALSE) +
  geom_text(aes(label = species), size = 10, x = -5, y = 1.5, hjust = 0, vjust = 0.5, check_overlap = TRUE, fontface = "italic") +
  labs(title=NULL, x="log10 scale Relative abundance", y=NULL, fill = "Host Species") +
  theme_bw() +
  theme(axis.text=element_text(size= 30),
        legend.title=element_text(size = 30, face = "bold"), 
        legend.text= element_text(size = 30),
        axis.title = element_text(size = 35, face = "bold", color = "white"),
        strip.text = element_blank(),
        strip.background = element_blank()) +
  scale_fill_manual(values = species.colors) +
  xlim(-5, 1) + 
  ylim(0, 1.6) + 
  facet_wrap(~ species, scale = "free_y", ncol= 1, strip.position="right")

# missing heatmap
{
  missing_df_dog = df %>% 
    select(c(1:2, 27:34)) %>% 
    filter(`Host Species` == "dog")
  missing_df_dog[-c(1:2)] = ifelse(is.na(missing_df_dog[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_dog[3:10])
  proportion =  (colSums(missing_df_dog[3:10])/nrow(missing_df_dog[3:10]))*100
  host = c("dog")
  
  dog = data.frame(species, proportion, host)
  
  missing_df_cat = df %>% 
    select(c(1:2, 27:34)) %>% 
    filter(`Host Species` == "cat")
  missing_df_cat[-c(1:2)] = ifelse(is.na(missing_df_cat[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_cat[3:10])
  proportion =  (colSums(missing_df_cat[3:10])/nrow(missing_df_cat[3:10]))*100
  host = c("cat")
  
  cat = data.frame(species, proportion, host)
  
  missing_df_human = df %>% 
    select(c(1:2, 27:34)) %>% 
    filter(`Host Species` == "human")
  missing_df_human[-c(1:2)] = ifelse(is.na(missing_df_human[-c(1:2)]), 1, 0)
  
  species = colnames(missing_df_human[3:10])
  proportion =  (colSums(missing_df_human[3:10])/nrow(missing_df_human[3:10]))*100
  host = c("human")
  
  human = data.frame(species, proportion, host)
  
  missing_df_p = rbind(cat, dog, human)
  missing_df_p$species <- factor(missing_df_p$species, levels = unique(df_set4$species))
  
  missing_barplot4 = ggplot(missing_df_p, aes(x = host, y = proportion, fill = host)) +
    geom_bar(stat="identity") +
    theme_bw() +
    theme(
      axis.text.x = element_text(size = 30, color = "white"),
      axis.text.y = element_text(size = 30),
      axis.ticks.x = element_blank(),
      axis.title.y = element_text(size = 35, face = "bold", color = "white"),
      axis.title.x = element_text(size = 35, face = "bold", color = "white"),
      strip.text = element_blank(),
      strip.background = element_blank()) +
    scale_fill_manual(values = species.colors) +
    ylim(0, 100) +
    labs(y = "Proportion (%) of missing value", fill = NULL, x = "Host Species", title = NULL) +
    facet_wrap(~ species, ncol= 1, strip.position="right") +
    guides(fill ="none")
  }

plot4 = grid.arrange(missing_barplot4, density_plot4, ncol = 2, widths = c(0.5, 1.5))

legend = get_legend(density_plot) # set any density_plot1/2/3/4 show.legend = T
bottom = textGrob("log10 Scale Relative Abundance", gp = gpar(fontsize = 60, fontface = "bold"))
yleft = textGrob("Proportion (%) of Missing Values", rot = 90, gp = gpar(fontsize = 60, fontface = "bold"))

plot = grid.arrange(plot1, plot2, plot3, plot4, legend, ncol = 5,
                    bottom = bottom,
                    left = yleft, widths = c(1, 1, 1, 1, 0.3))

ggsave(plot, file = paste0("Taxonomic profiling/PDFforTobyn/density_all_supplement.pdf"), height = 30, width = 43, dpi = 300, limitsize = FALSE)




